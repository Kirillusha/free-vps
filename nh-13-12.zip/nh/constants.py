import os

RESTART_INFO_FILE = "restart.txt"
IDS_MESSAGE_DIR = "ids_message"
STATUS_IDS_FILE = os.path.join(IDS_MESSAGE_DIR, "status_message_ids.json")
STATS_MESSAGE_ID_FILE = os.path.join(IDS_MESSAGE_DIR, "stats_message_id.json")
CLEANUP_PROPOSAL_MESSAGE_ID_FILE = os.path.join(
    IDS_MESSAGE_DIR, "cleanup_proposal_message_id.json")
