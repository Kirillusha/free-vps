import asyncio
import logging
import math
from html import escape
from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest
import server_config
import uuid
import os
import system_manager as sm
import database as db
from channel_logger import log_event
import keyboards as kb
from config_manager import config
import json
from constants import CLEANUP_PROPOSAL_MESSAGE_ID_FILE

CHECK_SEMAPHORE = asyncio.Semaphore(10)
CLEANUP_CANDIDATES_CACHE = {}
SESSION_VIOLATION_CACHE = set()

def _read_cleanup_message_id():
    if not os.path.exists(CLEANUP_PROPOSAL_MESSAGE_ID_FILE):
        return None
    try:
        with open(CLEANUP_PROPOSAL_MESSAGE_ID_FILE, 'r') as f:
            data = json.load(f)
            return data.get("message_id")
    except (json.JSONDecodeError, FileNotFoundError):
        return None

def _write_cleanup_message_id(message_id: int):
    os.makedirs(os.path.dirname(CLEANUP_PROPOSAL_MESSAGE_ID_FILE), exist_ok=True)
    with open(CLEANUP_PROPOSAL_MESSAGE_ID_FILE, 'w') as f:
        json.dump({"message_id": message_id}, f)

def pluralize_session(count):
    if count % 10 == 1 and count % 100 != 11:
        return "сессия"
    elif 2 <= count % 10 <= 4 and (count % 100 < 10 or count % 100 >= 20):
        return "сессии"
    else:
        return "сессий"

async def check_server_for_missing_sessions(ip: str) -> list:
    userbots_on_server = await db.get_userbots_by_server_ip(ip)
    if not userbots_on_server:
        return []

    check_script = ""
    for ub in userbots_on_server:
        name = ub['ub_username']
        check_script += f"if ! ls /root/api/volumes/{name}/data/*.session 1> /dev/null 2>&1; then echo {name}; fi\n"
    
    async with CHECK_SEMAPHORE:
        res = await sm.run_command_async(check_script, ip, check_output=False, timeout=60)
    
    missing_session_bots = []
    if res.get("success") and res.get("output"):
        found_names = res["output"].strip().split('\n')
        for name in found_names:
            name = name.strip()
            if not name: continue
            
            bot_data = next((b for b in userbots_on_server if b['ub_username'] == name), None)
            if bot_data:
                missing_session_bots.append(bot_data)
                
    return missing_session_bots

async def collect_missing_session_userbots() -> list:
    servers = server_config.get_servers()
    remote_ips = [ip for ip in servers if ip != sm.LOCAL_IP]
    
    tasks = [check_server_for_missing_sessions(ip) for ip in remote_ips]
    results = await asyncio.gather(*tasks)
    
    all_candidates = []
    for res in results:
        all_candidates.extend(res)
        
    return all_candidates

async def run_missing_session_check_and_propose_cleanup(bot: Bot, manual_trigger: bool = False):
    candidates = await collect_missing_session_userbots()
    
    old_message_id = _read_cleanup_message_id()
    chat_id = config.LOG_CHAT_ID
    
    if not candidates:
        if manual_trigger and old_message_id:
             try:
                await bot.edit_message_text(
                    chat_id=chat_id,
                    message_id=old_message_id,
                    text="✅ <b>Мусор не обнаружен.</b>\nВсе юзерботы имеют файлы сессий.",
                    reply_markup=kb.get_cleanup_refresh_only_keyboard(),
                    parse_mode="HTML"
                )
             except Exception:
                 pass
        elif old_message_id:
            try:
                await bot.delete_message(chat_id=chat_id, message_id=old_message_id)
                if os.path.exists(CLEANUP_PROPOSAL_MESSAGE_ID_FILE):
                    os.remove(CLEANUP_PROPOSAL_MESSAGE_ID_FILE)
            except Exception:
                pass
        return

    cleanup_id = uuid.uuid4().hex
    CLEANUP_CANDIDATES_CACHE[cleanup_id] = candidates
    
    count = len(candidates)
    text_lines = [f"🗑 <b>Обнаружен мусор ({count} шт):</b>\n"]
    
    servers_info = server_config.get_servers()
    
    by_server = {}
    for bot_data in candidates:
        ip = bot_data['server_ip']
        if ip not in by_server: by_server[ip] = []
        by_server[ip].append(bot_data['ub_username'])
        
    for ip, names in by_server.items():
        s_code = servers_info.get(ip, {}).get("code", ip)
        text_lines.append(f"<b>{s_code}:</b> {', '.join(names)}")
        
    text_lines.append("\n<i>Эти контейнеры не имеют файла сессии. Удалить их?</i>")
    final_text = "\n".join(text_lines)
    
    markup = kb.get_cleanup_confirmation_keyboard(cleanup_id)
    
    if old_message_id:
        try:
            await bot.edit_message_text(
                chat_id=chat_id,
                message_id=old_message_id,
                text=final_text,
                reply_markup=markup,
                parse_mode="HTML"
            )
            return
        except TelegramBadRequest:
            pass
            
    sent = await bot.send_message(
        chat_id=chat_id,
        text=final_text,
        reply_markup=markup,
        parse_mode="HTML",
        message_thread_id=13
    )
    _write_cleanup_message_id(sent.message_id)

async def _check_sessions_on_server(ip: str):
    base_path = "/root/api/volumes"
    command = f"""
    for D in {base_path}/ub*/data; do
        if [ -d "$D" ]; then
            SESSION_FILES=$(find "$D" -maxdepth 1 -type f -name "*.session" -printf "%f\\n")
            SESSION_COUNT=$(echo "$SESSION_FILES" | grep -c .)
            UB_NAME=$(basename "$(dirname "$D")")
            CLEAN_FILES=$(echo "$SESSION_FILES" | tr '\\n' ',' | sed 's/,$//')
            echo "${{UB_NAME}}:${{SESSION_COUNT}}:${{CLEAN_FILES}}"
        fi
    done
    """

    async with CHECK_SEMAPHORE:
        res = await sm.run_command_async(command, ip, check_output=True, timeout=180)

    suspicious = {}
    normal = {}

    if res.get("success") and res.get("output"):
        all_bots_on_server = {bot['ub_username'] for bot in await db.get_userbots_by_server_ip(ip)}

        found_on_server = set()
        for line in res["output"].strip().splitlines():
            if ":" not in line:
                continue

            parts = line.split(":", 2)
            if len(parts) != 3:
                continue

            name, count_str, files_str = parts
            found_on_server.add(name)
            try:
                count = int(count_str)
            except ValueError:
                count = 0

            files = files_str.split(',') if files_str else []
            user_data = {'count': count, 'files': files}

            if count > 1:
                suspicious[name] = user_data
            else:
                normal[name] = user_data

        for bot_name in all_bots_on_server:
            if bot_name not in found_on_server:
                normal[bot_name] = {'count': 0, 'files': []}

    return suspicious, normal

async def check_all_remote_sessions():
    servers = server_config.get_servers()
    remote_servers_ips = [ip for ip in servers if ip != sm.LOCAL_IP]

    if not remote_servers_ips:
        return {}

    tasks = [_check_sessions_on_server(ip) for ip in remote_servers_ips]
    results = await asyncio.gather(*tasks)

    server_session_map = {}
    for ip, (suspicious, normal) in zip(remote_servers_ips, results):
        server_session_map[ip] = {"suspicious": suspicious, "normal": normal}

    return server_session_map

async def format_session_check_report(server_results: dict, view_mode: str, page: int = 0):
    servers_info = server_config.get_servers()
    all_usernames = {uname for ip_data in server_results.values()
                     for view in ip_data.values() for uname in view.keys()}
    ub_data_tasks = [db.get_userbot_data(username)
                     for username in all_usernames]
    ub_data_results = await asyncio.gather(*ub_data_tasks)
    ub_data_map = {
        uname: data for uname,
        data in zip(
            all_usernames,
            ub_data_results) if data}

    if view_mode == "suspicious":
        header = "⚠️ <b>Пользователи с >1 сессией:</b>\n"
        suspicious_by_server = {}
        for ip, session_data in server_results.items():
            if session_data.get("suspicious"):
                suspicious_by_server[ip] = session_data["suspicious"]

        if not suspicious_by_server:
            return "<blockquote>✅ Проверка завершена. Подозрительных пользователей не найдено.</blockquote>", 1

        content_parts = []
        for ip, users in sorted(
            suspicious_by_server.items(), key=lambda item: servers_info.get(
                item[0], {}).get(
                'name', item[0])):
            server_details = servers_info.get(ip, {})
            server_flag = server_details.get("flag", "🏳️")
            server_code = server_details.get("code", "N/A")
            user_lines = []
            for username, data in sorted(users.items()):
                ub_data = ub_data_map.get(username)
                owner_id = ub_data.get('tg_user_id') if ub_data else None
                owner_info = ""
                if owner_id:
                    owner_data = await db.get_user_data(owner_id)
                    owner_info = f"<i>({escape(owner_data.get('full_name', ''))}, <code>{owner_id}</code>)</i>" if owner_data else f"<i>(ID: <code>{owner_id}</code>)</i>"

                files_str = ", ".join(
                    [f"<code>{escape(f)}</code>" for f in data['files']])
                user_lines.append(
                    f"  - <b>{escape(username)}</b> {owner_info}\n    └ 📂 {data['count']} шт.: {files_str}")

            content_parts.append(
                f"<b>{server_flag} {server_code}</b>\n" +
                "\n".join(user_lines))

        full_text = "<blockquote>" + header + "\n" + \
            "\n\n".join(content_parts) + "</blockquote>"
        return full_text, 1

    else:
        header = "✅ <b>Пользователи с 0 или 1 сессией:</b>\n"
        ITEMS_PER_PAGE = 15

        all_normal_users = []
        for ip, session_data in server_results.items():
            server_details = servers_info.get(ip, {})
            for username, data in session_data.get("normal", {}).items():
                all_normal_users.append(
                    {
                        'username': username,
                        'count': data['count'],
                        'server_code': server_details.get(
                            'code',
                            'N/A'),
                        'server_flag': server_details.get(
                            'flag',
                            '🏳️')})

        if not all_normal_users:
            return "<blockquote>ℹ️ В этой категории нет пользователей.</blockquote>", 1

        all_normal_users.sort(key=lambda x: (x['server_code'], x['username']))

        total_pages = math.ceil(len(all_normal_users) / ITEMS_PER_PAGE)
        page = max(0, min(page, total_pages - 1))
        start_idx = page * ITEMS_PER_PAGE
        end_idx = start_idx + ITEMS_PER_PAGE

        paginated_users = all_normal_users[start_idx:end_idx]

        user_lines = []
        for user in paginated_users:
            ub_data = ub_data_map.get(user['username'])
            owner_id = ub_data.get('tg_user_id') if ub_data else 'N/A'
            user_lines.append(
                f"{user['server_flag']} {user['server_code']} - <b>{escape(user['username'])}</b> (<code>{owner_id}</code>) - {user['count']} {pluralize_session(user['count'])}")

        content_text = "\n".join(user_lines)
        pagination_info = f"\n📄 Страница {page + 1} из {total_pages}" if total_pages > 1 else ""

        full_text = "<blockquote>" + header + "\n" + \
            content_text + pagination_info + "</blockquote>"

        return full_text, total_pages

async def check_and_log_session_violations(bot: Bot, force: bool = False) -> int:
    if not force:
        logging.info("Running scheduled check for session violations...")

    server_results = await check_all_remote_sessions()
    if not server_results:
        return 0

    servers_info = server_config.get_servers()
    all_suspicious_users = {}

    for ip, data in server_results.items():
        for username, session_data in data.get("suspicious", {}).items():
            if username not in all_suspicious_users:
                all_suspicious_users[username] = {
                    'ip': ip,
                    'count': session_data['count'],
                    'files': session_data['files']
                }

    if not all_suspicious_users:
        if not force:
            logging.info("No session violations found.")
        return 0

    violations_found_count = 0
    for username, details in all_suspicious_users.items():
        if not force and username in SESSION_VIOLATION_CACHE:
            continue

        violations_found_count += 1
        ub_data = await db.get_userbot_data(username)
        if not ub_data:
            continue

        owner_id = ub_data.get('tg_user_id')
        owner_data = await db.get_user_data(owner_id) if owner_id else None

        user_info_for_log = {"id": owner_id}
        if owner_data:
            user_info_for_log["full_name"] = owner_data.get('full_name', '')

        server_details = servers_info.get(details['ip'], {})

        files_str = "\n".join(
            [f"    - <code>{escape(f)}</code>" for f in details['files']])

        user_info_display = f"<code>{username}</code>"
        if owner_data:
            full_name = escape(owner_data.get('full_name', ''))
            user_link = f"<a href='tg://user?id={owner_id}'>{full_name}</a>"
            user_info_display = f"{user_link} (<code>{owner_id}</code>)"

        formatted_text = (
            f"<b>Пользователь:</b> {user_info_display}\n"
            f"<b>Юзербот:</b> <code>{escape(username)}</code>\n"
            f"<b>Сервер:</b> {server_details.get('flag', '🏳️')} {server_details.get('code', 'N/A')}\n\n"
            f"🔎 <b>Обнаружено сессий:</b> {details['count']} шт.\n"
            f"📂 <b>Файлы сессий:</b>\n{files_str}")

        log_data = {
            "user_data": user_info_for_log, "ub_info": {
                "name": username}, "server_info": {
                "ip": details['ip'], "code": server_details.get(
                    'code', 'N/A')}, "formatted_text": formatted_text}

        await log_event(bot, "session_violation", log_data)

        if not force:
            SESSION_VIOLATION_CACHE.add(username)
        await asyncio.sleep(1)

    return violations_found_count