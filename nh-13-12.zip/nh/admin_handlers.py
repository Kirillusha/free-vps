import aiohttp
import math
import logging
import json
import os
import uuid
import sys
import asyncio
import subprocess
import time
import asyncssh
from datetime import datetime, date, timedelta
from html import escape
import shlex
import re
import secrets
import shutil
import pytz

from aiogram import Router, types, Bot, F, html
from aiogram.filters import Command, CommandObject, StateFilter
from aiogram.fsm.context import FSMContext
from aiogram.exceptions import TelegramBadRequest, TelegramNotFound, TelegramForbiddenError
from aiogram.types import InlineKeyboardButton, BufferedInputFile, FSInputFile
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.types import Message, CallbackQuery
from collections import defaultdict
from config_manager import add_super_admin, remove_super_admin, config
from admin_manager import add_admin, remove_admin, get_admin_ids, get_all_admins
from constants import CLEANUP_PROPOSAL_MESSAGE_ID_FILE

import database as db
import system_manager as sm
import server_config
import keyboards as kb
import ban_manager
import session_checker
from api_manager import api_manager
from filters import IsAdmin, IsSuperAdmin
from broadcaster import broadcast_message
from constants import RESTART_INFO_FILE
from states import AdminTasks, AdminUserBotTransfer
from middlewares.error_handler import handle_error_page_callback
from middlewares import techwork as maintenance_manager
from channel_logger import log_to_channel, log_event


router = Router()

SESSION_CHECK_CACHE = {}
CACHE_TTL = 300
LOG_LINES_PER_PAGE = 25
ACTIVE_STATUS_LAST_REFRESH = 0
STATS_CACHE = {}
CACHE_TTL_SECONDS = 60
CONTAINER_LIST_CACHE = {}
CONTAINER_CACHE_TTL = 600
USERS_CACHE = {}
USERS_CACHE_TTL = 120

SERVERS_PAGE_SIZE = 10
API_CONFIG_PAGE_SIZE = 10
SERVERINFO_PAGE_SIZE = 5

ALLOWED_TABLES_FOR_UPDATE = ["userbots", "users"]


async def _generate_container_list_page(containers_on_page: list, total_containers: int, expanded_container_name: str | None = None) -> str:
    text_parts = [
        f"<b>📦 Управление контейнерами</b> (Всего: {total_containers})\n"
    ]

    for container in containers_on_page:
        name = container.get('name', 'Unknown')
        status = container.get('status', 'unknown')
        server_code = container.get('server_code', 'N/A')
        server_flag = container.get('server_flag', '🏳️')
        ub_type = container.get('ub_type', 'N/A')
        owner_info = container.get('owner_info', '<i>Владелец не найден</i>')

        status_icon = "🟢" if status == 'running' else "🔴"
        
        container_block = (
            f"<blockquote>"
            f"{status_icon} <b>{html.quote(name)}</b> <code>[{html.quote(ub_type).upper()}]</code>\n"
            f"📍 {server_flag} <b>{server_code}</b> | 👤 {owner_info}"
        )

        res = container.get('resources')
        is_expanded = (name == expanded_container_name) and res

        if is_expanded:
            def safe_float(key):
                val = res.get(key)
                try:
                    return float(val) if val is not None else 0.0
                except (ValueError, TypeError):
                    return 0.0

            cpu = safe_float('cpu_percent')
            ram = safe_float('ram_used')
            ram_lim = safe_float('ram_limit')
            disk = safe_float('disk_used')
            disk_lim = safe_float('disk_limit')

            container_block += (
                f"\n\n<b>📊 Ресурсы:</b>\n"
                f"├ 🧠 CPU: <code>{cpu:.1f}%</code>\n"
                f"├ 💾 RAM: <code>{ram:.0f}/{ram_lim:.0f} MB</code>\n"
                f"└ 💽 ROM: <code>{disk:.0f}/{disk_lim:.0f} MB</code>"
            )

        container_block += "</blockquote>"
        text_parts.append(container_block)

    return "\n".join(text_parts)


def _get_container_keyboard(page_containers: list, page: int, total_pages: int, expanded_name: str | None = None, loading_name: str | None = None):
    builder = InlineKeyboardBuilder()
    
    for container in page_containers:
        name = container['name']
        
        if name == loading_name:
            builder.row(InlineKeyboardButton(
                text=f"⏳ Загрузка...",
                callback_data="admin_noop"
            ))
        elif name == expanded_name:
            builder.row(InlineKeyboardButton(
                text=f"🔽 Скрыть {name}",
                callback_data=f"container_stats:hide:{name}:{page}"
            ))
        else:
            builder.row(InlineKeyboardButton(
                text=f"📊 {name}",
                callback_data=f"container_stats:show:{name}:{page}"
            ))

    nav_buttons = []
    if page > 0:
        nav_buttons.append(InlineKeyboardButton(text="⬅️", callback_data=f"container_page:{page-1}"))
    
    nav_buttons.append(InlineKeyboardButton(text=f"📄 {page+1}/{total_pages}", callback_data="admin_noop"))
    
    if page < total_pages - 1:
        nav_buttons.append(InlineKeyboardButton(text="➡️", callback_data=f"container_page:{page+1}"))
    
    builder.row(*nav_buttons)
    
    builder.row(InlineKeyboardButton(text="🔄 Обновить список", callback_data="container_page:refresh"))
    
    return builder.as_markup()


async def _update_container_message(message: types.Message, page: int, expanded_container_name: str | None = None, loading_container_name: str | None = None):
    cached_data = CONTAINER_LIST_CACHE.get(message.message_id)
    if not cached_data:
        try:
            await message.edit_text("⚠️ Данные устарели. Обновите список через /container list")
        except: pass
        return

    all_containers = cached_data['data']
    per_page = 5
    total_pages = math.ceil(len(all_containers) / per_page) if all_containers else 1

    page = max(0, min(page, total_pages - 1))
    
    start_index = page * per_page
    end_index = start_index + per_page
    containers_on_page = all_containers[start_index:end_index]

    page_text = await _generate_container_list_page(containers_on_page, len(all_containers), expanded_container_name)
    markup = _get_container_keyboard(containers_on_page, page, total_pages, expanded_container_name, loading_container_name)

    try:
        await message.edit_text(page_text, reply_markup=markup)
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Error updating container list: {e}")


@router.message(Command("container"), IsSuperAdmin())
async def cmd_container(message: types.Message, command: CommandObject, bot: Bot):
    args = command.args.split() if command.args else []
    action = args[0].lower() if args else "help"

    if action == "list":
        msg = await message.reply("⏳ <b>Сбор данных о контейнерах...</b>", reply_markup=kb.get_loading_keyboard())

        servers = server_config.get_servers()
        list_tasks = [api_manager.get_container_list(ip) for ip, d in servers.items() if d.get('status') != 'false']
        results = await asyncio.gather(*list_tasks, return_exceptions=True)

        all_containers_info = []
        active_servers = [(ip, d) for ip, d in servers.items() if d.get('status') != 'false']
        
        for (ip, details), res in zip(active_servers, results):
            if isinstance(res, dict) and res.get("success") and res.get('data', {}).get('list'):
                for cont in res['data']['list']:
                    all_containers_info.append({
                        "name": cont['name'],
                        "status": cont.get('status', 'unknown'),
                        "server_ip": ip,
                        "server_code": details.get('code', 'N/A'),
                        "server_flag": details.get('flag', '🏳️')
                    })

        if not all_containers_info:
            await msg.edit_text("❌ <b>Контейнеры не найдены</b>\nНи на одном из серверов нет активных контейнеров.")
            return

        db_tasks = [db.get_userbot_data(info['name']) for info in all_containers_info]
        ub_data_list = await asyncio.gather(*db_tasks)

        for info, ub_data in zip(all_containers_info, ub_data_list):
            if ub_data:
                owner_data = await db.get_user_data(ub_data['tg_user_id'])
                info['ub_type'] = ub_data.get('ub_type', 'N/A')
                if owner_data:
                    u_name = owner_data.get('full_name', 'Unknown')
                    u_id = ub_data['tg_user_id']
                    # Ссылка на пользователя
                    info['owner_info'] = f"<a href='tg://user?id={u_id}'>{html.quote(u_name)}</a>"
                else:
                    info['owner_info'] = f"ID: <code>{ub_data['tg_user_id']}</code>"
            else:
                info['owner_info'] = "<i>Нет в БД</i>"
                
        all_containers_info.sort(key=lambda x: x['name'])

        CONTAINER_LIST_CACHE[msg.message_id] = {
            "data": all_containers_info,
            "timestamp": time.time(),
            "expanded": None
        }

        await _update_container_message(msg, 0)

    elif action == "exec":
        if len(args) < 3:
            await message.reply(
                "<b>ℹ️ Справка: exec</b>\n\n"
                "Формат: <code>/container exec [имя] [команда]</code>\n"
                "Пример: <code>/container exec ub123 ls -la</code>"
            )
            return

        container_name = args[1]
        command_to_exec = " ".join(args[2:])

        msg = await message.reply(f"⏳ Выполняю: <code>{html.quote(command_to_exec)}</code>...")

        ub_data = await db.get_userbot_data(ub_username=container_name)
        if not ub_data:
            await msg.edit_text(f"❌ Контейнер <code>{html.quote(container_name)}</code> не найден в БД.")
            return

        server_ip = ub_data['server_ip']
        exec_result = await api_manager.exec_in_container(container_name, command_to_exec, server_ip)

        if not exec_result.get("success"):
            error_text = exec_result.get('error', 'API Error')
            await msg.edit_text(f"❌ <b>Ошибка выполнения:</b>\n<pre>{html.quote(error_text)}</pre>")
            return

        data = exec_result.get("data", {}).get("exec", {})
        exit_code = data.get("exit_code", "N/A")
        output = data.get("output", "").strip()

        text = (
            f"🖥 <b>Консоль:</b> <code>{html.quote(container_name)}</code>\n"
            f"⌨️ <b>Команда:</b> <code>{html.quote(command_to_exec)}</code>\n"
            f"📡 <b>Exit Code:</b> {exit_code}\n\n"
        )

        if output:
            if len(output) > 3500:
                output = output[:3500] + "\n... [обрезано]"
            text += f"📄 <b>Вывод:</b>\n<pre>{html.quote(output)}</pre>"
        else:
            text += "<i>(Пустой вывод)</i>"

        await msg.edit_text(text)

    else:
        help_text = (
            "📦 <b>Управление контейнерами</b>\n\n"
            "<code>/container list</code> - Список всех контейнеров\n"
            "<code>/container exec [имя] [cmd]</code> - Выполнить команду"
        )
        await message.reply(help_text)


@router.message(Command("exec_all"), IsSuperAdmin())
async def cmd_exec_all(message: types.Message, command: CommandObject):
    if not command.args:
        servers = server_config.get_servers()
        codes = [details.get("code")
                 for details in servers.values() if details.get("code")]
        codes_str = ", ".join(f"<code>{c}</code>" for c in codes)
        help_text = (
            "<b>🖥️ Выполнение команды во всех контейнерах на сервере</b>\n\n"
            "<b>Формат:</b>\n"
            "   <code>/exec_all [код] [команда]</code>\n\n"
            "<i>Пример:</i>\n"
            "   <code>/exec_all M5 ls /data/</code>\n\n"
            f"<b>Доступные коды серверов:</b> {codes_str}"
        )
        await message.reply(help_text)
        return

    args = command.args.split(maxsplit=1)
    if len(args) < 2:
        await message.reply("<b>Ошибка:</b> Неверный формат.\nИспользование: <code>/exec_all [код] [команда]</code>")
        return

    server_code, cmd_str = args[0], args[1]

    target_ip = find_ip_by_code(server_code)
    if not target_ip:
        await message.reply(f"❌ Сервер с кодом <code>{server_code}</code> не найден.")
        return

    msg = await message.reply(
        f"⏳ Выполняю <code>{html.quote(cmd_str)}</code> во всех контейнерах на сервере <b>{server_code}</b>..."
    )

    try:
        res = await api_manager.exec_all(cmd_str, target_ip)
    except Exception as e:
        await msg.edit_text(f"❌ Ошибка выполнения: <code>{html.quote(str(e))}</code>")
        return

    results = res.get("data", {}).get("exec_all", {})
    
    report_lines = [
        f"<b>🚀 Выполнение команды на сервере {server_code}:</b>\n"
        f"<pre><code>{html.quote(cmd_str)}</code></pre>\n"
    ]
    success_count, fail_count = 0, 0

    for container, data in results.items():
        container_report = f"\n⎯⎯⎯⎯\n<b>Контейнер {container}</b>"

        if data.get("success"):
            success_count += 1
            exit_code = data["output"].get("exit_code", "N/A")
            container_report += f"\nСтатус: ✅ (код выхода {exit_code})"
            out_text = html.quote(data["output"].get("output", "").strip())
            if out_text:
                container_report += f"\n<pre><code>{out_text}</code></pre>"
            else:
                container_report += "\n<i>(нет вывода)</i>"
        else:
            fail_count += 1
            exit_code = data.get("output", {}).get("exit_code", "N/A")
            err_text = html.quote(
                data.get(
                    "output",
                    {}).get(
                    "output",
                    "Неизвестная ошибка"))
            container_report += f"\nСтатус: ❌ (код выхода {exit_code})"
            container_report += f"\n<pre><code>{err_text}</code></pre>"

        report_lines.append(container_report)

    summary = f"\n\n<b>Итог: {success_count} ✅ | {fail_count} ❌</b>"
    final_report = "".join(report_lines) + summary

    if len(final_report) > 4096:
        file = BufferedInputFile(
            final_report.encode("utf-8"),
            filename="exec_all_report.txt")
        await msg.delete()
        await message.answer_document(file, caption=f"Отчет о выполнении команды на {server_code}.")
    else:
        await msg.edit_text(final_report)


@router.callback_query(F.data.startswith("container_page:"))
async def cq_container_list_page(call: types.CallbackQuery):
    await call.answer()
    
    action = call.data.split(":")[1]
    
    if action == "refresh":
        await cmd_container(call.message, CommandObject(command="container", args="list"), call.bot)
        return

    try:
        page = int(action)
    except ValueError:
        return

    cached_data = CONTAINER_LIST_CACHE.get(call.message.message_id)
    if not cached_data or time.time() - cached_data['timestamp'] > CONTAINER_CACHE_TTL:
        await call.message.edit_text("⚠️ Сессия истекла. Используйте /container list снова.")
        return

    cached_data["expanded"] = None
    await _update_container_message(call.message, page)


@router.callback_query(F.data.startswith("container_stats:"))
async def cq_toggle_container_stats(call: types.CallbackQuery):
    try:
        _, action, name, page_str = call.data.split(":")
        page = int(page_str)
    except ValueError:
        await call.answer("Ошибка данных", show_alert=True)
        return

    cached_data = CONTAINER_LIST_CACHE.get(call.message.message_id)
    if not cached_data or time.time() - cached_data['timestamp'] > CONTAINER_CACHE_TTL:
        await call.answer("Данные устарели", show_alert=True)
        try:
            await call.message.edit_text("⚠️ Данные устарели. Обновите список.")
        except: pass
        return

    if action == "hide":
        await call.answer()
        cached_data["expanded"] = None
        await _update_container_message(call.message, page, None)
        return

    target_container = next((c for c in cached_data['data'] if c['name'] == name), None)
    if not target_container:
        await call.answer("Контейнер не найден в кэше", show_alert=True)
        return

    if 'resources' in target_container and target_container['resources'].get('cpu_percent') is not None:
        await call.answer()
        cached_data["expanded"] = name
        await _update_container_message(call.message, page, name)
        return

    await _update_container_message(call.message, page, None, loading_container_name=name)

    stats_result = await api_manager.get_container_stats(name, target_container['server_ip'])

    resources = {
        'cpu_percent': 0.0,
        'ram_used': 0.0,
        'ram_limit': 0.0,
        'disk_used': 0.0,
        'disk_limit': 0.0
    }

    if stats_result.get("success"):
        info = stats_result.get("data", {}).get("info", {})
        if info:
            resources['cpu_percent'] = float(info.get("cpu_percent") or 0)
            resources['ram_used'] = float(info.get("ram_usage_mb") or 0)
            resources['ram_limit'] = float(info.get("ram_limit_mb") or 0)
            resources['disk_used'] = float(info.get("disk_usage_mb") or 0)
            resources['disk_limit'] = float(info.get("disk_limit_mb") or 0)

    target_container['resources'] = resources
    cached_data["expanded"] = name

    await _update_container_message(call.message, page, name)

@router.message(F.text.regexp(r'^\/.*'), ~IsAdmin())
async def unauthorized_admin_command_attempt(message: types.Message, bot: Bot):
    user_info = f"{message.from_user.full_name} (@{message.from_user.username}, <code>{message.from_user.id}</code>)"
    log_text = (
        f"⚠️ <b>Попытка несанкционированного доступа</b>\n\n"
        f"<b>Пользователь:</b> {user_info}\n"
        f"<b>Команда:</b> <code>{html.quote(message.text)}</code>"
    )
    await log_to_channel(bot, log_text)
    await message.reply("⛔️ У вас нет прав для использования этой команды.")

router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())

router.callback_query.register(
    handle_error_page_callback,
    F.data.startswith("error_page:"))

TERMINAL_OUTPUT_CACHE = {}
TERMINAL_SESSIONS_ACTIVE = {}
MAX_CACHE_SIZE = 100
ACTIVE_PANEL_UPDATE_TASKS = {}


async def _get_geo_info(ip: str):
    fields = "status,message,country,regionName,city,org,timezone,hosting,query,countryCode,proxy,vpn"
    url = f"http://ip-api.com/json/{ip}?fields={fields}"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    if data.get("status") == "success":
                        return data
                return None
    except Exception:
        return None


def _country_code_to_flag(code: str) -> str:
    if not code or len(code) != 2:
        return "🏳️"
    return "".join(chr(ord(char) + 127397) for char in code.upper())


@router.message(Command("obs"), IsSuperAdmin())
async def cmd_obs_all_servers(message: types.Message, bot: Bot):
    await message.reply("❌ Функция обслуживания серверов временно недоступна.")
    return


def get_terminal_paginator(output_id: str, page: int, total_pages: int):
    builder = InlineKeyboardBuilder()
    nav_buttons = []
    if page > 0:
        nav_buttons.append(
            InlineKeyboardButton(
                text="‹ Назад",
                callback_data=f"term_page:{output_id}:{page-1}"))

    nav_buttons.append(
        InlineKeyboardButton(
            text=f"{page+1}/{total_pages}",
            callback_data="noop"))

    if page < total_pages - 1:
        nav_buttons.append(
            InlineKeyboardButton(
                text="Вперед ›",
                callback_data=f"term_page:{output_id}:{page+1}"))

    builder.row(*nav_buttons)
    return builder.as_markup()


@router.callback_query(F.data.startswith("term_page:"))
async def terminal_page_callback(call: types.CallbackQuery):
    try:
        _, output_id, page_str = call.data.split(":")
        page = int(page_str)
    except (ValueError, IndexError):
        await call.answer("Ошибка данных пагинации.", show_alert=True)
        return

    cached_data = TERMINAL_OUTPUT_CACHE.get(output_id)
    if not cached_data:
        await call.answer("Данные этого вывода устарели и были удалены из кэша.", show_alert=True)
        try:
            await call.message.edit_text(f"{call.message.html_text}\n\n<i>(Данные устарели)</i>", reply_markup=None)
        except TelegramBadRequest:
            pass
        return

    header, raw_chunks = cached_data
    total_pages = len(raw_chunks)

    if not (0 <= page < total_pages):
        await call.answer("Запрошенная страница не существует.", show_alert=True)
        return

    page_content = raw_chunks[page]

    new_text = f"{header}\n\n<blockquote>{html.quote(page_content)}</blockquote>"
    markup = get_terminal_paginator(output_id, page, total_pages)

    try:
        await call.message.edit_text(
            new_text,
            reply_markup=markup,
            disable_web_page_preview=True
        )
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Error editing terminal page: {e}")
    finally:
        await call.answer()


def find_ip_by_code(code: str) -> str | None:
    servers = server_config.get_servers()
    for ip, details in servers.items():
        if details.get("code") and details.get("code").lower() == code.lower():
            return ip
    return None


@router.message(Command("terminal"), IsSuperAdmin())
async def cmd_terminal(message: types.Message, command: CommandObject):
    if not command.args:
        servers = server_config.get_servers()
        codes = [details.get("code")
                 for details in servers.values() if details.get("code")]
        codes_str = ", ".join(f"<code>{c}</code>" for c in codes)
        help_text = (
            "<b>🖥️ Терминал — выполнение команд на серверах</b>\n\n"
            "<b>Формат использования:</b>\n\n"
            "🔹 <b>Локально:</b>\n"
            "   <code>/terminal [команда]</code>\n"
            "   <i>(Выполняет команду на сервере, где запущен бот)</i>\n\n"
            "🔹 <b>На одном сервере:</b>\n"
            "   <code>/terminal [код] [команда]</code>\n"
            "   <i>(Пример: <code>/terminal M1 ls -l</code>)</i>\n\n"
            "🔹 <b>На всех серверах:</b>\n"
            "   <code>/terminal all [команда]</code>\n"
            "   <i>(Выполняет команду на всех удаленных хостах)</i>\n\n"
            f"<b>Доступные коды серверов:</b> {codes_str}"
        )
        await message.reply(help_text)
        return

    args = command.args.split(maxsplit=1)

    if args[0].lower() == 'all':
        if len(args) < 2:
            await message.reply("<b>Ошибка:</b> Не указана команда для выполнения.\nИспользование: <code>/terminal all [команда]</code>")
            return

        cmd_str = args[1]
        msg = await message.reply(f"⏳ Выполняю <code>{html.quote(cmd_str)}</code> на всех удаленных серверах...")

        servers = server_config.get_servers()
        remote_servers = {
            ip: details for ip,
            details in servers.items() if ip != sm.LOCAL_IP}

        if not remote_servers:
            await msg.edit_text("❌ Нет настроенных удаленных серверов для выполнения команды.")
            return

        tasks = [sm.run_command_async(cmd_str, ip)
                 for ip in remote_servers.keys()]
        results = await asyncio.gather(*tasks)

        report_lines = [
            f"<b>🚀 Пакетное выполнение команды:</b>\n<pre><code>{html.quote(cmd_str)}</code></pre>\n"]
        success_count = 0
        fail_count = 0

        for server_details, result in zip(remote_servers.values(), results):
            flag = server_details.get("flag", "🏳️")
            name = server_details.get("name", "Unknown")
            code = server_details.get("code", "N/A")

            server_report_part = f"\n⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯\n<b>{flag} {name} ({code})</b>"

            if result.get("success"):
                success_count += 1
                server_report_part += "\nСтатус: ✅ Успешно"
                output_message = html.quote(result.get('output', '')).strip()
                if output_message:
                    server_report_part += f"\n<pre><code>{output_message}</code></pre>"
                else:
                    server_report_part += "\n<i>(нет вывода)</i>"
            else:
                fail_count += 1
                exit_code = result.get('exit_status', 'N/A')
                server_report_part += f"\nСтатус: ❌ Ошибка (Код выхода: {exit_code})"
                error_message = html.quote(
                    result.get('error') or "Нет текста ошибки.")
                server_report_part += f"\n<pre><code>{error_message}</code></pre>"

            report_lines.append(server_report_part)

        summary = f"\n\n<b>Итог: {success_count} ✅ | {fail_count} ❌</b>"
        final_report = "".join(report_lines) + summary

        if len(final_report) > 4096:
            report_file = BufferedInputFile(
                final_report.encode('utf-8'),
                filename="terminal_all_report.html")
            await msg.delete()
            await message.answer_document(report_file, caption="Отчет о выполнении команды на всех серверах.")
        else:
            await msg.edit_text(final_report)
        return

    target_ip = None
    cmd_str = ""
    server_display_name = ""

    potential_code = args[0]
    ip_from_code = find_ip_by_code(potential_code)

    if len(args) == 2 and ip_from_code:
        target_ip = ip_from_code
        cmd_str = args[1]
        server_display_name = potential_code.upper()
    else:
        target_ip = sm.LOCAL_IP
        cmd_str = command.args
        server_display_name = "Локально"

    if message.chat.type != 'private':
        sensitive_files = [
            "ip.json",
            "ip.json.bak",
            "config.json",
            "admins.json",
            "deleted_servers.json"]
        try:
            command_parts = shlex.split(cmd_str)
            for part in command_parts:
                for sensitive_file in sensitive_files:
                    if sensitive_file in part:
                        await message.reply("<b>Иди нахуй, хуй спалишь</b>")
                        return
        except ValueError:
            for sensitive_file in sensitive_files:
                if sensitive_file in cmd_str:
                    await message.reply("<b>Иди нахуй, хуй спалишь</b>")
                    return

    msg = await message.reply(f"⏳ Выполняю команду на <code>{server_display_name}</code>...")
    res = await sm.run_command_async(cmd_str, target_ip, timeout=600)

    output = res.get('output', '')
    error = res.get('error', '')
    exit_code = res.get('exit_status', 'N/A')

    header = (
        f"<b>⌨️ Системная команда <code>{html.quote(cmd_str)}</code></b>\n"
        f"<i>Код выхода: {exit_code}</i>"
    )

    content_parts = []
    if output:
        content_parts.append(
            f"📼 Stdout:\n<blockquote expandable>{html.quote(output)}</blockquote>")
    if error:
        content_parts.append(
            f"📼 Stderr:\n<blockquote expandable>{html.quote(error)}</blockquote>")

    if content_parts:
        full_text = f"{header}\n\n" + "\n\n".join(content_parts)
    else:
        full_text = f"{header}\n\n<i>(Нет вывода)</i>"

    if len(full_text) > 4096:
        await msg.delete()
        output_id = uuid.uuid4().hex

        raw_output_content = []
        if output:
            raw_output_content.append(f"📼 Stdout:\n{output}")
        if error:
            raw_output_content.append(f"\n📼 Stderr:\n{error}")

        raw_content_to_paginate = "\n".join(raw_output_content)

        available_space = 4096 - \
            len(header) - len("<blockquote expandable></blockquote>") - 20

        chunks = [raw_content_to_paginate[i:i + available_space]
                  for i in range(0, len(raw_content_to_paginate), available_space)]

        if len(TERMINAL_OUTPUT_CACHE) >= MAX_CACHE_SIZE:
            TERMINAL_OUTPUT_CACHE.pop(next(iter(TERMINAL_OUTPUT_CACHE)))

        TERMINAL_OUTPUT_CACHE[output_id] = (header, chunks)

        text_to_send = f"{header}\n\n<blockquote expandable>{html.quote(chunks[0])}</blockquote>"
        markup = get_terminal_paginator(output_id, 0, len(chunks))

        await message.answer(
            text_to_send,
            reply_markup=markup,
            disable_web_page_preview=True
        )
    else:
        await msg.edit_text(
            full_text,
            disable_web_page_preview=True
        )


@router.message(Command("serv"), IsSuperAdmin())
async def cmd_serv_manager(message: types.Message, command: CommandObject, bot: Bot):
    if not command.args:
        await message.reply("Недостаточно аргументов. Используйте <code>/serv help</code> для справки.")
        return

    args = command.args.split()
    action = args[0].lower()
    admin_data = {"id": message.from_user.id,
                  "full_name": message.from_user.full_name}
    servers = server_config.get_servers()

    if action == "help":
        help_text = (
            "<b>⚙️ Команды управления серверами:</b>\n\n"
            "<code>/serv list</code>\n"
            "<i>Показывает список всех серверов с их кодами.</i>\n\n"
            "<code>/serv add [IP] [user] [pass] [hostname] [код] [-i]</code>\n"
            "<i>Добавляет новый сервер. Пример: /serv add 192.168.1.100 root mypass mdkadmin.online M2 -i</i>\n\n"
            "<code>/serv del [код]</code>\n"
            "<i>Удаляет сервер из конфигурации.</i>\n\n"
            "<b>Команды для конкретного сервера:</b>\n"
            "<code>/serv [код] status [статус]</code>\n"
            "<i>Статусы: <code>true</code>, <code>false</code>, <code>noub</code>, <code>test</code>.</i>\n\n"
            "<code>/serv [код] setslot [число]</code>\n"
            "<i>Устанавливает лимит слотов.</i>\n\n"
            "<code>/serv setapi [код] [api_url] [api_token]</code>\n"
            "<i>Обновляет API URL и токен для сервера.</i>")
        await message.reply(help_text)
        return

    if action == "list":
        if not servers:
            await message.reply("Список серверов пуст.")
            return

        text_parts = ["<b>📋 Список настроенных серверов:</b>\n"]
        for i, (ip, details) in enumerate(servers.items(), 1):
            country = details.get('country', 'N/A')
            city = details.get('city', 'N/A')
            name = details.get('name', 'N/A')
            code = details.get('code', 'N/A')
            text_parts.append(
                f"{i}. <code>{ip}</code> (<b>код:</b> <code>{code}</code>) - {name}, {country}, {city}")
        await message.reply("\n".join(text_parts))
        return

    if action == "add":
        if len(args) < 6:
            await message.reply(f"Использование: <code>/serv add [IP] [user] [password] [hostname] [код] [-i]</code>\n\n"
                                f"Пример: <code>/serv add 192.168.1.100 root mypass mdkadmin.online M2 -i</code>")
            return

        do_install = False
        if len(args) > 6 and args[6] == "-i":
            do_install = True

        _, ip, user, password, hostname, code = args[:6]

        if ip in servers:
            await message.reply(f"❌ Сервер <code>{ip}</code> уже существует.")
            return

        existing_codes = [
            details.get("code") for details in servers.values() if details.get("code")]
        if code in existing_codes:
            await message.reply(f"❌ Сервер с кодом <code>{code}</code> уже существует.\n\n"
                                f"Доступные коды: {', '.join(f'<code>{c}</code>' for c in existing_codes)}")
            return

        existing_names = [
            details.get("name") for details in servers.values() if details.get("name")]
        i = 1
        while f"serv{i}" in existing_names:
            i += 1
        server_name = f"serv{i}"

        api_url = f"http://{ip}:8000"
        api_token = "ktLU8sj1/IOl6OK9JDwCe2vorWcUmB1w"

        msg = await message.reply(f"⏳ Проверяю SSH-соединение с <code>{ip}</code>...")

        temp_servers_to_test = servers.copy()
        temp_servers_to_test[ip] = {"ssh_user": user, "ssh_pass": password}
        server_config._save_servers(temp_servers_to_test)

        test_res = await sm.run_command_async("echo 'connection_ok'", ip)

        server_config._save_servers(servers)

        if not test_res.get("success"):
            await msg.edit_text(f"❌ <b>Ошибка подключения:</b>\n<pre>{html.quote(test_res.get('error', 'Неизвестная ошибка'))}</pre>")
            return

        await msg.edit_text(f"✅ Соединение успешно. Получаю информацию о сервере...")

        geo_info = await _get_geo_info(ip)
        details = {
            "name": server_name,
            "code": code,
            "api_url": api_url,
            "api_token": api_token
        }

        if geo_info:
            details.update({
                "country": geo_info.get("country", "Unknown"),
                "city": geo_info.get("city", "Unknown"),
                "regionName": geo_info.get("regionName", "N/A"),
                "flag": _country_code_to_flag(geo_info.get("countryCode", "")),
                "org": geo_info.get("org", "N/A"),
                "timezone": geo_info.get("timezone", "N/A"),
                "hosting": geo_info.get("hosting", False),
                "proxy": geo_info.get("proxy", False),
                "vpn": geo_info.get("vpn", False),
            })

        new_password = await sm.add_server_with_security(ip, user, password, details)
        if isinstance(new_password, str) and new_password:
            await msg.edit_text(f"✅ Сервер <b>{server_name}</b> (<code>{ip}</code>) с кодом <b>{code}</b> успешно добавлен.\n\n"
                                f"🌐 API URL: <code>{api_url}</code>\n\n"
                                "⏳ <b>Начинаю настройку сервера...</b>")
            await msg.reply(f"⏳ Меняю hostname на '{hostname}'...")
            set_hostname_res = await sm.run_command_async(f"sudo hostnamectl set-hostname {hostname}", ip, ssh_pass=new_password)
            if set_hostname_res.get("success"):
                await msg.reply(f"✅ Hostname успешно изменён на '{hostname}'.")
            else:
                await msg.reply(f"⚠️ Не удалось изменить hostname.\n<pre>{set_hostname_res.get('error','')}</pre>")

            if do_install:
                await msg.reply(f"⏳ Запускаю установку Docker и sharkapi на сервере <code>{ip}</code>...")
                install_cmd = (
                    "sudo apt update && sudo apt install -y ca-certificates curl gnupg lsb-release "
                    "&& sudo install -m 0755 -d /etc/apt/keyrings "
                    "&& curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg "
                    "&& echo \"deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable\" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null "
                    "&& sudo apt update "
                    "&& sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin python3-pip "
                    "&& sudo apt install -y apache2 apache2-utils "
                    "&& sudo a2enmod proxy && sudo a2enmod proxy_http && sudo a2enmod ssl && sudo a2enmod headers && sudo a2enmod rewrite "
                    "&& sudo systemctl restart apache2 "
                    "&& cd /root/ && git clone https://Plovchikdeval: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@github.com/Plovchikdeval/sharkapi.git api "
                    "&& cd api && pip install -r requirements.txt "
                    "&& echo \"[Unit]\nDescription=Запуск Python-приложения (app) из /projects/give\nAfter=network.target\n\n[Service]\nType=simple\nWorkingDirectory=/root/api\nExecStart=python3 -m app\nRestart=always\nRestartSec=15\nUser=root\nEnvironment=PYTHONUNBUFFERED=1\n\n[Install]\nWantedBy=multi-user.target\" > /etc/systemd/system/api.service "
                    "&& systemctl enable --now api "
                    "&& systemctl stop docker "
                    "&& mkdir -p /opt/docker-storage "
                    "&& fallocate -l 40G /opt/docker-storage/docker.img "
                    "&& mkfs.xfs -m reflink=1 -n ftype=1 /opt/docker-storage/docker.img "
                    "&& mount -o loop,pquota /opt/docker-storage/docker.img /var/lib/docker "
                    "&& grep -q '/var/lib/docker' /etc/fstab || echo '/opt/docker-storage/docker.img /var/lib/docker xfs loop,pquota 0 0' >> /etc/fstab "
                    "&& systemctl start docker "
                    "&& for userbot in legacy fox hikka heroku; do docker pull sharkhost/sharkhost:$userbot; done")
                res = await sm.run_command_async(install_cmd, ip, timeout=1800)
                output = res.get('output', '')
                error = res.get('error', '')
                exit_code = res.get('exit_status', 'N/A')
                if res.get('success'):
                    text = f"✅ <b>Установка завершена успешно на <code>{ip}</code></b>"
                else:
                    text = f"❌ <b>Ошибка установки на <code>{ip}</code></b>\nКод выхода: <code>{exit_code}</code>\n\n<pre>Ohhhh... error..</pre>"
                if len(text) > 4096:
                    from aiogram.types import BufferedInputFile
                    file = BufferedInputFile(
                        (output + '\n' + error).encode('utf-8'),
                        filename='install_log.txt')
                    await message.answer_document(file, caption=text[:1000])
                else:
                    await message.reply(text)
        else:
            await msg.edit_text(f"❌ Не удалось добавить сервер <code>{ip}</code>.")
        return

    if action == "del":
        if len(args) != 2:
            await message.reply("Использование: <code>/serv del [код]</code>")
            return
        server_code_to_del = args[1]
        ip_to_del = find_ip_by_code(server_code_to_del)
        if not ip_to_del:
            await message.reply(f"❌ Сервер с кодом <code>{html.quote(server_code_to_del)}</code> не найден.")
            return
        if server_config.delete_server(ip_to_del):
            await message.reply(f"✅ Сервер <code>{ip_to_del}</code> (код {server_code_to_del}) удален.")
        else:
            await message.reply(f"❌ Не удалось удалить сервер <code>{ip_to_del}</code> из конфигурации.")
        return

    if action == "setapi":
        if len(args) != 4:
            await message.reply("Использование: <code>/serv setapi [код] [api_url] [api_token]</code>\n\nПример: <code>/serv setapi M2 http://m7.mdkadmin.online.space:8000 kivWJm0e2ey9u50uCqEwCIcHstCwuZslu7QK4YcEsCTGQcUTx33JC3bZve0zvr8y</code>")
            return

        server_code = args[1]
        api_url = args[2]
        api_token = args[3]

        ip_to_update = find_ip_by_code(server_code)
        if not ip_to_update:
            await message.reply(f"❌ Сервер с кодом <code>{server_code}</code> не найден.")
            return

        servers[ip_to_update]["api_url"] = api_url
        servers[ip_to_update]["api_token"] = api_token
        if server_config._save_servers(servers):
            await message.reply(f"✅ API конфигурация для сервера <code>{server_code}</code> обновлена:\n\n🌐 URL: <code>{api_url}</code>\n🔑 Token: <code>{api_token}</code>")
        else:
            await message.reply(f"❌ Не удалось обновить API конфигурацию для сервера <code>{server_code}</code>")
        return

    if len(args) < 2 and len(args) != 1:
        await message.reply("Неверный формат команды. Используйте <code>/serv help</code>.")
        return

    server_code = args[0]
    target_ip = find_ip_by_code(server_code)

    if not target_ip:
        await message.reply(f"Сервер с кодом <code>{server_code}</code> не найден. Используйте <code>/serv list</code>.")
        return

    sub_action = args[1].lower() if len(args) > 1 else 'status'

    if sub_action == "install":
        msg = await message.reply(f"⏳ Запускаю установку Docker и sharkapi на сервере <code>{target_ip}</code>...")
        install_cmd = (
            "sudo apt update && sudo apt install -y ca-certificates curl gnupg lsb-release "
            "&& sudo install -m 0755 -d /etc/apt/keyrings "
            "&& curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg "
            "&& echo \"deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable\" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null "
            "&& sudo apt update "
            "&& sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin python3-pip "
            "&& sudo apt install -y apache2 apache2-utils "
            "&& sudo a2enmod proxy && sudo a2enmod proxy_http && sudo a2enmod ssl && sudo a2enmod headers && sudo a2enmod rewrite "
            "&& sudo systemctl restart apache2 "
            "&& cd /root/ && git clone https://Plovchikdeval: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@github.com/Plovchikdeval/sharkapi.git api "
            "&& cd api && pip install -r requirements.txt "
            "&& echo \"[Unit]\nDescription=Запуск Python-приложения (app) из /projects/give\nAfter=network.target\n\n[Service]\nType=simple\nWorkingDirectory=/root/api\nExecStart=python3 -m app\nRestart=always\nRestartSec=15\nUser=root\nEnvironment=PYTHONUNBUFFERED=1\n\n[Install]\nWantedBy=multi-user.target\" > /etc/systemd/system/api.service "
            "&& systemctl enable --now api "
            "&& systemctl stop docker "
            "&& mkdir -p /opt/docker-storage "
            "&& fallocate -l 40G /opt/docker-storage/docker.img "
            "&& mkfs.xfs -m reflink=1 -n ftype=1 /opt/docker-storage/docker.img "
            "&& mount -o loop,pquota /opt/docker-storage/docker.img /var/lib/docker "
            "&& grep -q '/var/lib/docker' /etc/fstab || echo '/opt/docker-storage/docker.img /var/lib/docker xfs loop,pquota 0 0' >> /etc/fstab "
            "&& systemctl start docker "
            "&& for userbot in legacy fox hikka heroku; do docker pull sharkhost/sharkhost:$userbot; done")
        res = await sm.run_command_async(install_cmd, target_ip, timeout=1800)
        output = res.get('output', '')
        error = res.get('error', '')
        exit_code = res.get('exit_status', 'N/A')
        if res.get('success'):
            text = f"✅ <b>Установка завершена успешно на <code>{target_ip}</code></b>\n\n<pre>{html.quote(output)}</pre>"
        else:
            text = f"❌ <b>Ошибка установки на <code>{target_ip}</code></b>\nКод выхода: <code>{exit_code}</code>\n\n<pre>{html.quote(error or output)}</pre>"
        if len(text) > 4096:
            from aiogram.types import BufferedInputFile
            file = BufferedInputFile(
                (output + '\n' + error).encode('utf-8'),
                filename='install_log.txt')
            await msg.delete()
            await message.answer_document(file, caption=text[:1000])
        else:
            await msg.edit_text(text)
        return

    if sub_action == "uninstall":
        msg = await message.reply(f"⏳ Запускаю удаление Docker, sharkapi и связанных файлов на сервере <code>{target_ip}</code>...")
        uninstall_cmd = (
            "systemctl disable --now api || true && "
            "rm -f /etc/systemd/system/api.service && "
            "rm -rf /root/api && "
            "systemctl stop docker || true && "
            "umount /var/lib/docker || true && "
            "sed -i '\\|/opt/docker-storage/docker.img /var/lib/docker|d' /etc/fstab && "
            "rm -f /opt/docker-storage/docker.img && "
            "rm -rf /opt/docker-storage && "
            "apt purge -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin python3-pip apache2 apache2-utils && "
            "apt autoremove -y && "
            "rm -f /etc/apt/keyrings/docker.gpg && "
            "rm -f /etc/apt/sources.list.d/docker.list && "
            "apt update")
        res = await sm.run_command_async(uninstall_cmd, target_ip, timeout=1800)
        output = res.get('output', '')
        error = res.get('error', '')
        exit_code = res.get('exit_status', 'N/A')
        if res.get('success'):
            text = f"✅ <b>Удаление завершено успешно на <code>{target_ip}</code></b>\n\n<pre>{html.quote(output)}</pre>"
        else:
            text = f"❌ <b>Ошибка удаления на <code>{target_ip}</code></b>\nКод выхода: <code>{exit_code}</code>\n\n<pre>{html.quote(error or output)}</pre>"
        if len(text) > 4096:
            from aiogram.types import BufferedInputFile
            file = BufferedInputFile(
                (output + '\n' + error).encode('utf-8'),
                filename='uninstall_log.txt')
            await msg.delete()
            await message.answer_document(file, caption=text[:1000])
        else:
            await msg.edit_text(text)
        return

    elif sub_action == "setslot":
        if len(args) != 3:
            await message.reply(f"Использование: <code>/serv [код] setslot [число]</code>")
            return
        try:
            slots = int(args[2])
            if slots < 0:
                raise ValueError
            if server_config.update_server_slots(target_ip, slots):
                await message.reply(f"✅ Для сервера <code>{server_code}</code> установлено <b>{slots}</b> слотов.")
                log_data = {
                    "admin_data": admin_data,
                    "server_info": {
                        "ip": target_ip,
                        "code": server_code},
                    "details": f"установлено новое количество слотов: {slots}"}
                await log_event(bot, "server_settings_changed", log_data)
            else:
                await message.reply("❌ Не удалось обновить количество слотов.")
        except ValueError:
            await message.reply("Количество слотов должно быть целым неотрицательным числом.")

    elif sub_action == "auth":
        if len(args) != 3:
            await message.reply("Использование: <code>/serv [код] auth [auto|port]</code>")
            return
        auth_mode = args[2].lower()
        if auth_mode not in ["auto", "port"]:
            await message.reply("Неверный режим. Доступные: <code>auto</code>, <code>port</code>.")
            return

        if server_config.update_server_auth_mode(target_ip, auth_mode):
            mode_description = "поиск ссылки в логах" if auth_mode == "auto" else "статический порт для WebUI"
            await message.reply(f"✅ Режим авторизации для сервера <code>{server_code}</code> изменен на <b>{auth_mode}</b> ({mode_description}).")
            log_data = {
                "admin_data": admin_data,
                "server_info": {
                    "ip": target_ip,
                    "code": server_code},
                "details": f"режим авторизации изменен на '{auth_mode}'"}
            await log_event(bot, "server_settings_changed", log_data)
        else:
            await message.reply("❌ Не удалось обновить режим авторизации.")

    elif sub_action == "status":
        if len(args) != 3:
            await message.reply("Использование: <code>/serv [код] status [true|false|noub|test|premium]</code>")
            return
        status_value = args[2].lower()
        if status_value not in ["true", "false", "noub", "test", "premium"]:
            await message.reply("Неверный статус. Доступные: true, false, noub, test, premium.")
            return
        if server_config.update_server_status(target_ip, status_value):
            await message.reply(f"✅ Статус сервера <code>{server_code}</code> изменен на <b>{status_value}</b>.")
            log_data = {
                "admin_data": admin_data,
                "server_info": {
                    "ip": target_ip,
                    "code": server_code},
                "details": f"статус изменен на '{status_value}'"}
            await log_event(bot, "server_settings_changed", log_data)
        else:
            await message.reply("❌ Не удалось обновить статус сервера.")


def create_progress_bar(percentage, length=10):
    try:
        percentage = float(percentage)
        filled = int(percentage / 100 * length)
        filled = max(0, min(filled, length))
    except (ValueError, TypeError):
        filled = 0
    empty = length - filled

    if filled == length:
        bar = '█' * filled
    else:
        bar = '█' * filled + '░' * empty

    return bar


async def _get_full_server_info_text(stats_map, servers_to_display: list):
    text_parts = ["🌟 <b>Мониторинг серверов</b>\n"]

    for ip, details in servers_to_display:
        stats = stats_map.get(ip, {})
        ub_count = len(await db.get_userbots_by_server_ip(ip))

        def safe_float(value, default=0):
            try:
                if isinstance(value, str):
                    value = ''.join(
                        c for c in value if c.isdigit() or c == '.')
                return float(value) if value else default
            except (ValueError, TypeError):
                return default

        cpu_usage = safe_float(stats.get('cpu_usage', 0))
        cpu_cores = stats.get('cpu_cores', '?')
        ram_percent = safe_float(stats.get('ram_percent', 0))
        ram_total = stats.get('ram_total', 'N/A')
        disk_percent = safe_float(stats.get('disk_percent', 0))
        disk_total = stats.get('disk_total', 'N/A')
        uptime = stats.get('uptime', 'N/A')

        cpu_bar = create_progress_bar(cpu_usage)
        ram_bar = create_progress_bar(ram_percent)
        disk_bar = create_progress_bar(disk_percent)

        if cpu_usage < 80 and ram_percent < 80:
            status_emoji = "🟢"
        elif cpu_usage < 90:
            status_emoji = "🟡"
        else:
            status_emoji = "🔴"

        server_block = (
            "<blockquote expandable>"
            f"\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"┃ <b>{status_emoji} {(details.get('name', 'Unknown'))}</b>\n"
            f"┃ <code>{details.get('code', 'N/A')}</code> • {details.get('flag', '🏳️')}\n"
            f"┃\n"
            f"┃ 📍 <b>Локация</b>\n"
            f"┃   {(details.get('country', 'N/A'))}, {(details.get('city', 'N/A'))}\n"
            f"┃   {(details.get('org', 'N/A'))}\n"
            f"┃\n"
            f"┃ 💻 <b>Характеристики</b>\n"
            f"┃   • CPU: {cpu_cores} ядер\n"
            f"┃   • RAM: {ram_total}\n"
            f"┃   • Disk: {disk_total}\n"
            f"┃\n"
            f"┃ 📈 <b>Нагрузка</b>\n"
            f"┃   • CPU: {cpu_bar} <code>{cpu_usage:.1f}%</code>\n"
            f"┃   • RAM: {ram_bar} <code>{ram_percent:.1f}%</code>\n"
            f"┃   • Disk: {disk_bar} <code>{disk_percent:.1f}%</code>\n"
            f"┃\n"
            f"┃ ⏱️ <b>Uptime:</b> {uptime}\n"
            f"┃ 🤖 <b>Юзерботы:</b> <code>{ub_count} шт.</code>\n"
            f"┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "</blockquote>")
        text_parts.append(server_block)

    return "".join(text_parts)


async def auto_update_server_info_panel(bot: Bot, chat_id: int, message_id: int):
    while True:
        await asyncio.sleep(180)
        try:
            info_text, _ = await _get_server_info_content()

            await bot.edit_message_text(
                text=info_text,
                chat_id=chat_id,
                message_id=message_id,
                reply_markup=kb.get_server_info_keyboard()
            )
        except TelegramBadRequest as e:
            if "message to edit not found" in str(e).lower(
            ) or "message can't be edited" in str(e).lower():
                logging.warning(
                    f"Message {message_id} in chat {chat_id} for auto-update not found. Stopping task.")
                if chat_id in ACTIVE_PANEL_UPDATE_TASKS:
                    del ACTIVE_PANEL_UPDATE_TASKS[chat_id]
                break
            elif "message is not modified" not in str(e).lower():
                logging.error(f"Error auto-updating server info panel: {e}")
        except Exception as e:
            logging.error(
                f"Unexpected error in auto-update task: {e}",
                exc_info=True)


async def start_or_reset_update_task(bot: Bot, chat_id: int, message_id: int):
    if chat_id in ACTIVE_PANEL_UPDATE_TASKS:
        ACTIVE_PANEL_UPDATE_TASKS[chat_id].cancel()
        logging.info(f"Cancelled previous update task for chat {chat_id}")

    task = asyncio.create_task(
        auto_update_server_info_panel(
            bot, chat_id, message_id))
    ACTIVE_PANEL_UPDATE_TASKS[chat_id] = task
    logging.info(
        f"Started new auto-update task for chat {chat_id}, message {message_id}")


async def _get_server_info_content(page: int = 1):
    servers = server_config.get_servers()
    remote_servers = [(ip, details)
                      for ip, details in servers.items() if ip != "127.0.0.1"]
    total_servers = len(remote_servers)
    if not remote_servers:
        return "Список удаленных серверов пуст.", None, 1, 1

    total_pages = max(
        1,
        (total_servers +
         SERVERINFO_PAGE_SIZE -
         1) //
        SERVERINFO_PAGE_SIZE)
    page = max(1, min(page, total_pages))
    start = (page - 1) * SERVERINFO_PAGE_SIZE
    end = start + SERVERINFO_PAGE_SIZE
    servers_on_page = remote_servers[start:end]

    stats_tasks = [sm.get_server_stats(ip) for ip, _ in servers_on_page]
    all_stats = await asyncio.gather(*stats_tasks)
    stats_map = dict(zip([ip for ip, _ in servers_on_page], all_stats))

    info_text = await _get_full_server_info_text(stats_map, servers_on_page)

    from keyboards import get_server_info_paginator_keyboard
    markup = get_server_info_paginator_keyboard(page, total_pages)
    return info_text, markup, page, total_pages


@router.message(Command("serverinfo"))
async def cmd_server_info(message: types.Message, bot: Bot):
    msg = await message.reply("⏳ Собираю информацию...")
    info_text, markup, page, total_pages = await _get_server_info_content(page=1)
    if "пуст" in info_text:
        await msg.edit_text(info_text)
        return
    sent_message = await msg.edit_text(
        text=info_text,
        reply_markup=markup
    )
    await start_or_reset_update_task(bot, sent_message.chat.id, sent_message.message_id)


@router.callback_query(F.data.startswith("serverinfo_page:"))
async def serverinfo_page_callback(call: types.CallbackQuery, bot: Bot):
    await call.answer()
    try:
        page = int(call.data.split(":")[1])
    except Exception:
        page = 1
    info_text, markup, page, total_pages = await _get_server_info_content(page=page)
    try:
        await call.message.edit_text(
            text=info_text,
            reply_markup=markup
        )
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            import logging
            logging.error(f"Ошибка обновления serverinfo_page: {e}")
    await start_or_reset_update_task(bot, call.message.chat.id, call.message.message_id)


@router.callback_query(F.data == "refresh_server_info")
async def refresh_server_info_handler(call: types.CallbackQuery, bot: Bot):
    await call.answer("Обновляю...")

    info_text, markup, _, _ = await _get_server_info_content()

    try:
        await call.message.edit_text(
            text=info_text,
            reply_markup=markup
        )
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Failed to edit message text on refresh: {e}")

    await start_or_reset_update_task(bot, call.message.chat.id, call.message.message_id)


@router.message(Command("restart"), IsSuperAdmin())
async def cmd_restart_bot(message: types.Message):
    try:
        msg = await message.reply("⏳ Перезапускаюсь...")

        restart_info = {"chat_id": msg.chat.id, "message_id": msg.message_id}
        with open(RESTART_INFO_FILE, "w") as f:
            json.dump(restart_info, f)

        await asyncio.sleep(1)

        os.execv(sys.executable, [sys.executable] + sys.argv)

    except Exception as e:
        logging.error(f"Failed to execute restart: {e}")
        try:
            await msg.edit_text(f"❌ Не удалось перезапустить бота. Ошибка: {e}")
        except BaseException:
            pass


@router.message(Command("stop"), IsSuperAdmin())
async def cmd_stop_bot(message: types.Message):
    await message.reply("Останавливаю бота. Для запуска используйте консоль.")
    loop = asyncio.get_running_loop()
    loop.stop()


@router.message(Command("server"), IsSuperAdmin())
async def cmd_server_toggle(message: types.Message, command: CommandObject, bot: Bot):
    arg = command.args.lower() if command.args else None
    current_status_is_on = not maintenance_manager.is_maintenance_mode()
    admin_data = {"id": message.from_user.id,
                  "full_name": message.from_user.full_name}

    if arg == "on":
        if not current_status_is_on:
            maintenance_manager.set_maintenance_mode(False)
            await message.reply("✅ Бот включен для пользователей.")
            await log_event(bot, "maintenance_mode_off", {"admin_data": admin_data})
        else:
            await message.reply("✅ Бот уже был включен.")
    elif arg == "off":
        if current_status_is_on:
            maintenance_manager.set_maintenance_mode(True)
            await message.reply("⚙️ Бот переведен в режим тех. работ.")
            await log_event(bot, "maintenance_mode_on", {"admin_data": admin_data})
        else:
            await message.reply("⚙️ Бот уже был в режиме тех. работ.")
    else:
        status = "Включен ✅" if current_status_is_on else "Выключен (тех. работы) ⚙️"
        await message.reply(
            f"<b>Текущий статус для пользователей:</b> {status}\n\n"
            f"Использование: <code>/server [on|off]</code>"
        )


@router.message(Command("ahelp"), IsAdmin())
async def cmd_ahelp(message: types.Message):
    text = (
        "<blockquote>"
        "<b>Админ-панель: Справка по командам</b>\n\n"
        "<b>👤 Пользователи и Доступ</b>\n"
        "<code>/users</code> — Список пользователей (постранично).\n"
        "<code>/user [ID|@]</code> — Инфо о пользователе.\n"
        "<code>/ban</code>, <code>/unban</code> — Блокировка/разблокировка.\n"
        "<code>/admin [add|del] [admin|super]</code> — Управление админами (Супер).\n\n"
        
        "<b>🖥️ Серверы и Инфраструктура</b>\n"
        "<code>/servers</code> — Список серверов.\n"
        "<code>/serverinfo</code> — Интерактивный мониторинг ресурсов.\n"
        "<code>/serv help</code> — Управление нодами (add/del/status/auth/setslot).\n"
        "<code>/terminal [код] [команда]</code> — SSH консоль.\n"
        "<code>/server [on/off]</code> — Режим тех. работ.\n"
        "<code>/set_api_token</code>, <code>/set_api_url</code> — Настройка API ноды.\n"
        "<code>/show_api_config</code> — Просмотр конфигов API.\n\n"
        
        "<b>🐳 Контейнеры (Юзерботы)</b>\n"
        "<code>/container list</code> — Список всех контейнеров Docker.\n"
        "<code>/container exec</code> — Команда внутри контейнера.\n"
        "<code>/exec_all [код] [команда]</code> — Команда во всех контейнерах сервера.\n"
        "<code>/delub [имя] [-d|-f]</code> — Удаление (с флагами: -d только БД, -f форс).\n\n"
        
        "<b>🛡️ Диагностика и Обслуживание</b>\n"
        "<code>/check</code> — Проверка на >1 сессию (дубли).\n"
        "<code>/update_check</code> — Принудительная проверка дублей.\n"
        "<code>/update_ns</code> — Поиск и очистка юзерботов <b>без сессии</b>.\n"
        "<code>/backup_bot</code> — Создать полный бэкап бота.\n"
        "<code>/git</code> — Управление репозиторием бота.\n"
        "<code>/restart</code>, <code>/stop</code> — Управление процессом бота.\n\n"
        
        "<b>📣 Разное</b>\n"
        "<code>/bc</code> — Рассылка (ответом на сообщение).\n"
        "</blockquote>")
    await message.reply(text, disable_web_page_preview=True)


@router.callback_query(F.data == "no_action")
async def no_action_handler(call: types.CallbackQuery):
    await call.answer()


@router.callback_query(F.data == "admin_noop")
async def admin_noop_handler(call: types.CallbackQuery):
    await call.answer("Функция управления временно недоступна.")


@router.message(Command("check"), IsSuperAdmin())
async def cmd_check_sessions(message: types.Message):
    msg = await message.reply("⏳ Ищу пользователей с несколькими сессиями на серверах...")
    try:
        server_results = await session_checker.check_all_remote_sessions()

        SESSION_CHECK_CACHE[message.chat.id] = {
            "data": server_results,
            "timestamp": time.time()
        }

        view_mode = "suspicious"
        report, total_pages = await session_checker.format_session_check_report(server_results, view_mode, page=0)
        markup = kb.get_session_check_keyboard(
            view_mode, page=0, total_pages=total_pages)

        await msg.edit_text(text=report, reply_markup=markup)

    except Exception as e:
        logging.error(f"Ошибка во время выполнения /check: {e}", exc_info=True)
        await msg.edit_text(f"❌ Произошла ошибка во время проверки: {e}")


@router.callback_query(F.data.startswith("check_view_toggle:"), IsSuperAdmin())
async def check_view_toggle_handler(call: types.CallbackQuery):
    await call.answer()
    await call.message.edit_reply_markup(reply_markup=kb.get_loading_keyboard())

    cached_data = SESSION_CHECK_CACHE.get(call.message.chat.id)
    if not cached_data or time.time() - cached_data["timestamp"] > CACHE_TTL:
        await call.message.edit_text("Данные для этого отчета устарели. Пожалуйста, выполните /check снова.", reply_markup=None)
        return

    new_view_mode = call.data.split(":")[1]

    server_results = cached_data["data"]
    report, total_pages = await session_checker.format_session_check_report(server_results, new_view_mode, page=0)
    markup = kb.get_session_check_keyboard(
        new_view_mode, page=0, total_pages=total_pages)

    try:
        await call.message.edit_text(text=report, reply_markup=markup)
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Ошибка обновления отчета /check: {e}")


@router.callback_query(F.data.startswith("check_page:"), IsSuperAdmin())
async def check_page_handler(call: types.CallbackQuery):
    await call.answer()
    cached_data = SESSION_CHECK_CACHE.get(call.message.chat.id)
    if not cached_data or time.time() - cached_data["timestamp"] > CACHE_TTL:
        await call.message.edit_text("Данные для этого отчета устарели, выполните /check снова.", reply_markup=None)
        return

    try:
        _, view_mode, page_str = call.data.split(":")
        page = int(page_str)
    except (ValueError, IndexError):
        return

    server_results = cached_data["data"]
    report, total_pages = await session_checker.format_session_check_report(server_results, view_mode, page=page)
    markup = kb.get_session_check_keyboard(
        view_mode, page=page, total_pages=total_pages)

    try:
        await call.message.edit_text(text=report, reply_markup=markup)
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Ошибка обновления страницы отчета /check: {e}")


@router.callback_query(F.data == "refresh_session_check", IsSuperAdmin())
async def refresh_session_check_handler(call: types.CallbackQuery):
    cached_data = SESSION_CHECK_CACHE.get(call.message.chat.id)
    now = time.time()
    if cached_data and now - cached_data["timestamp"] < 5:
        await call.answer("Обновлять можно не чаще, чем раз в 5 секунд!", show_alert=True)
        return

    current_view_mode = "suspicious"
    if call.message.reply_markup:
        for row in call.message.reply_markup.inline_keyboard:
            for button in row:
                if button.callback_data == "check_view_toggle:normal":
                    current_view_mode = "suspicious"
                    break
                elif button.callback_data == "check_view_toggle:suspicious":
                    current_view_mode = "normal"
                    break

    await call.answer("Обновляю...")
    await call.message.edit_reply_markup(reply_markup=kb.get_loading_keyboard())

    server_results = await session_checker.check_all_remote_sessions()
    SESSION_CHECK_CACHE[call.message.chat.id] = {
        "data": server_results,
        "timestamp": now
    }
    report, total_pages = await session_checker.format_session_check_report(server_results, current_view_mode, page=0)
    markup = kb.get_session_check_keyboard(
        current_view_mode, page=0, total_pages=total_pages)

    await call.message.edit_text(text=report, reply_markup=markup)


@router.message(Command("bc"), IsSuperAdmin())
async def cmd_broadcast(message: types.Message, command: CommandObject, bot: Bot):
    replied_message = message.reply_to_message
    if not replied_message:
        await message.reply(
            "<b>⚠️ Неверное использование.</b>\n\n"
            "Ответьте командой <code>/bc</code> на сообщение для рассылки.\n"
            "Для целевой отправки: <code>/bc [ID или @username]</code>.\n"
            "Для рассылки по серверам: <code>/bc [код1] [код2] ...</code> (например: <code>/bc M2 M3</code>)"
        )
        return

    users_to_notify = set()
    is_targeted = False
    target_identifier = "всех пользователей"
    server_codes = set()
    servers = server_config.get_servers()

    if command.args:
        args = command.args.strip().split()
        for arg in args:
            for ip, details in servers.items():
                if details.get("code", "").lower() == arg.lower():
                    server_codes.add(arg.upper())
                    break
        if server_codes:
            is_targeted = True
            target_identifier = ", ".join(server_codes)
            ips = [
                ip for ip,
                details in servers.items() if details.get(
                    "code",
                    "").upper() in server_codes]
            all_owners = set()
            for ip in ips:
                userbots = await db.get_userbots_by_server_ip(ip)
                for ub in userbots:
                    all_owners.add(ub['tg_user_id'])
            users_to_notify = all_owners
            if not users_to_notify:
                await message.reply(f"❌ Нет пользователей с юзерботами на серверах: {target_identifier}")
                return
        else:
            is_targeted = True
            target_identifier = command.args.strip()
            target_user_data = await db.get_user_by_username_or_id(target_identifier)
            if target_user_data:
                users_to_notify.add(target_user_data['tg_user_id'])
            else:
                await message.reply(f"❌ Пользователь <code>{html.quote(target_identifier)}</code> не найден в базе данных.")
                return
    else:
        users_to_notify = set(await db.get_all_bot_users())

    if not users_to_notify:
        await message.reply("В базе нет пользователей для рассылки.")
        return

    status_text = (
        f"Начинаю целевую отправку для <b>{html.quote(target_identifier)}</b>..."
        if is_targeted else "Начинаю массовую рассылку..."
    )
    msg = await message.reply(text=status_text, reply_markup=kb.get_loading_keyboard())

    result = await broadcast_message(
        bot=bot,
        users=list(users_to_notify),
        from_chat_id=replied_message.chat.id,
        message_id=replied_message.message_id
    )

    final_status = (
        "✅ Целевая отправка завершена." if is_targeted else "✅ <b>Рассылка завершена.</b>"
    )
    await msg.edit_text(
        f"{final_status}\n\n"
        f"<b>Отправлено:</b> {result['sent']}\n"
        f"<b>Не удалось:</b> {result['failed']}"
    )


REASON_TEMPLATES = {
    "no_reason": "Без указания причины",
    "inactive": "Неактивность (юзербот занимает слот)",
    "abuse": "Злоупотребление сервисом / Систематические нарушения",
    "tos_violation": "Нарушение пользовательского соглашения",
    "multiaccount": "Мультиаккаунт (создание нескольких юзерботов)",
    "cpu_load": "Критическая нагрузка на CPU",
    "ram_load": "Чрезмерное потребление RAM",
    "spam_activity": "Рассылка спама / Жалобы от пользователей",
    "phishing": "Фишинг / Вредоносная активность",
    "owner_request": "По просьбе владельца",
    "forbidden_content": "Распространение запрещенного контента",
    "technical_work": "Технические работы на сервере"
}


@router.message(Command("delub"), IsSuperAdmin())
async def cmd_delub(message: types.Message, command: CommandObject, bot: Bot):
    if not command.args:
        help_text = (
            "<b>Использование:</b> <code>/delub [имя_юзербота] [флаги]</code>\n\n"
            "<b>Примеры:</b>\n"
            "• <code>/delub ub12345</code> - стандартное удаление с выбором причины.\n"
            "• <code>/delub ub12345 -d</code> - удаление только из базы данных бота.\n"
            "• <code>/delub ub12345 -f 1.2.3.4</code> - принудительное полное удаление с сервера (если нет в БД).")
        await message.reply(help_text)
        return

    args = command.args.split()
    ub_name = args[0]

    if "-d" in args:
        msg = await message.reply(f"🗑️ Удаляю <code>{html.quote(ub_name)}</code> только из <b>базы данных</b>...")
        ub_data = await db.get_userbot_data(ub_username=ub_name)
        if not ub_data:
            await msg.edit_text(f"❌ Юзербот <code>{html.quote(ub_name)}</code> не найден в базе данных.")
            return

        if await db.delete_userbot_record(ub_name):
            await msg.edit_text(f"✅ Запись о юзерботе <code>{html.quote(ub_name)}</code> была удалена из базы данных.")

            admin_data = {
                "id": message.from_user.id,
                "full_name": message.from_user.full_name}
            owner_data = {"id": ub_data.get('tg_user_id')}
            server_details = server_config.get_servers().get(ub_data.get('server_ip'), {})
            log_data = {
                "admin_data": admin_data, "user_data": owner_data, "ub_info": {
                    "name": ub_name}, "server_info": {
                    "ip": ub_data.get('server_ip'), "code": server_details.get(
                        "code", "N/A")}, "reason": "Удаление только из БД (флаг -d)"}
            await log_event(bot, "deletion_by_admin", log_data)
        else:
            await msg.edit_text(f"❌ Произошла ошибка при удалении <code>{html.quote(ub_name)}</code> из базы данных.")
        return

    if "-f" in args:
        try:
            ip_index = args.index('-f') + 1
            if ip_index >= len(args):
                await message.reply("❗ Укажите IP сервера после флага -f.")
                return
            server_ip = args[ip_index]
        except (ValueError, IndexError):
            await message.reply("❗ Неверный формат для принудительного удаления. Укажите IP сервера после флага -f.")
            return

        await message.reply(f"🗑️ Принудительно удаляю <code>{html.quote(ub_name)}</code> с сервера <code>{html.quote(server_ip)}</code> и из БД...")
        res = await api_manager.delete_container(ub_name, server_ip)
        if res.get("success"):
            await message.reply(f"✅ Юзербот <code>{html.quote(ub_name)}</code> был полностью удален с сервера <code>{html.quote(server_ip)}</code> и из БД.")
        else:
            await message.reply(f"❌ Ошибка при принудительном удалении <code>{html.quote(ub_name)}</code>: {res.get('error', '...')}")
        return

    if not await db.get_userbot_data(ub_username=ub_name):
        await message.reply(f"❌ Юзербот <code>{html.quote(ub_name)}</code> не найден.")
        return

    text = f"Выберите причину удаления для юзербота <code>{html.quote(ub_name)}</code>:"
    markup = kb.get_delub_reason_keyboard(ub_name, REASON_TEMPLATES)
    await message.reply(text, reply_markup=markup)


@router.callback_query(F.data == "delub_close_menu")
async def cq_delub_close_menu(call: types.CallbackQuery):
    await call.message.delete()
    await call.answer()


@router.callback_query(F.data.startswith("delub_confirm:"))
async def cq_delub_reason_selected(call: types.CallbackQuery):
    _, ub_username, reason_code = call.data.split(":")
    reason_text = REASON_TEMPLATES.get(reason_code, "Причина не указана.")

    text = (
        f"<b>⚠️ Подтверждение удаления</b>\n\n"
        f"<b>Юзербот:</b> <code>{html.quote(ub_username)}</code>\n"
        f"<b>Причина:</b> {html.quote(reason_text)}\n\n"
        "Вы уверены, что хотите продолжить?"
    )
    markup = kb.get_delub_final_confirm_keyboard(ub_username, reason_code)
    await call.message.edit_text(text, reply_markup=markup)
    await call.answer()


@router.callback_query(F.data.startswith("delub_cancel:"))
async def cq_delub_cancel(call: types.CallbackQuery):
    ub_username = call.data.split(":")[1]
    text = f"Выберите причину удаления для юзербота <code>{html.quote(ub_username)}</code>:"
    markup = kb.get_delub_reason_keyboard(ub_username, REASON_TEMPLATES)
    await call.message.edit_text(text, reply_markup=markup)
    await call.answer("Удаление отменено.")


@router.callback_query(F.data.startswith("delub_execute:"))
async def cq_delub_execute(call: types.CallbackQuery, bot: Bot):
    try:
        _, ub_username, reason_code = call.data.split(":")
        reason_text = REASON_TEMPLATES.get(reason_code, "Причина не указана.")
        await call.message.edit_text(f"🗑️ Удаляю <code>{html.quote(ub_username)}</code>...", reply_markup=None)

        ub_data = await db.get_userbot_data(ub_username)
        if not ub_data:
            await call.message.edit_text("❌ Юзербот уже был удален.")
            return

        owner_id = ub_data.get('tg_user_id')
        server_ip = ub_data.get('server_ip')

        res = await api_manager.delete_container(ub_username, server_ip)
        await db.delete_password(owner_id)
        await db.delete_vpn(owner_id)
        await api_manager.delete_vpn(f"ub{owner_id}")

        if res is None or not res.get("success"):
            error_message = res.get(
                'error',
                'Не удалось получить ответ от сервера') if res else 'Не удалось получить ответ от сервера'
            await call.message.edit_text(f"❌ Ошибка при удалении <code>{html.quote(ub_username)}</code>: {error_message}")
            return

        await db.delete_userbot_record(ub_username)

        await call.message.edit_text(f"✅ Юзербот <code>{html.quote(ub_username)}</code> был полностью удален.")

        admin_data = {
            "id": call.from_user.id,
            "full_name": call.from_user.full_name}
        owner_data = {"id": owner_id}
        try:
            owner_chat = await bot.get_chat(owner_id)
            owner_data["full_name"] = owner_chat.full_name
        except Exception:
            pass

        server_details = server_config.get_servers().get(server_ip, {})
        log_data = {
            "admin_data": admin_data, "user_data": owner_data, "ub_info": {
                "name": ub_username}, "server_info": {
                "ip": server_ip, "code": server_details.get(
                    "code", "N/A")}, "reason": reason_text}
        await log_event(bot, "deletion_by_admin", log_data)

        if owner_id and reason_code != "no_reason":
            try:
                await bot.send_message(
                    chat_id=owner_id,
                    text=f"‼️ <b>Ваш юзербот был удален администратором.</b>\n\n<b>Причина:</b> {html.quote(reason_text)}"
                )
            except Exception as e:
                logging.warning(
                    f"Не удалось уведомить {owner_id} об удалении UB: {e}")
    except Exception as e:
        logging.error(f"Ошибка в cq_delub_execute: {e}")
        try:
            await call.message.edit_text(f"❌ Произошла ошибка при удалении юзербота: {str(e)}")
        except Exception:
            logging.error(
                f"Не удалось отредактировать сообщение об ошибке: {e}")


async def _get_all_active_containers() -> dict:
    servers = server_config.get_servers()
    tasks = []
    server_ips = []

    for ip, details in servers.items():
        if details.get('status') == 'false':
            continue
        tasks.append(api_manager.get_container_list(ip))
        server_ips.append((ip, details))

    if not tasks:
        return {}

    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    active_containers = {}

    for (ip, details), result in zip(server_ips, results):
        if isinstance(result, Exception):
            logging.error(f"Error fetching containers from {ip}: {result}")
            continue
        
        if isinstance(result, dict) and result.get("success"):
            containers = result.get("data", {}).get("list", [])
            for cont in containers:
                name = cont.get('name')
                status = cont.get('status')
                if name:
                    active_containers[name] = {
                        'status': status,
                        'server_ip': ip,
                        'server_code': details.get('code', 'N/A'),
                        'server_flag': details.get('flag', '🏳️')
                    }
    
    return active_containers

async def _get_users_data_with_status(force_refresh=False):
    global USERS_CACHE
    current_time = time.time()

    if not force_refresh and USERS_CACHE.get("data") and (current_time - USERS_CACHE.get("timestamp", 0) < USERS_CACHE_TTL):
        return USERS_CACHE["data"]

    all_users = await db.get_all_registered_users()
    all_bots = await db.get_all_userbots_full_info()
    
    containers_status = await _get_all_active_containers()

    users_map = {u['tg_user_id']: u for u in all_users}
    for u in all_users:
        u['bots'] = []
        u['sort_priority'] = 3

    for bot in all_bots:
        owner_id = bot['tg_user_id']
        if owner_id in users_map:
            ub_name = bot['ub_username']
            
            real_info = containers_status.get(ub_name)
            if real_info:
                bot['real_status'] = real_info['status']
                bot['server_code'] = real_info['server_code']
                bot['server_flag'] = real_info['server_flag']
            else:
                bot['real_status'] = 'unknown'
                srv = server_config.get_servers().get(bot['server_ip'], {})
                bot['server_code'] = srv.get('code', 'N/A')
                bot['server_flag'] = srv.get('flag', '🏳️')

            users_map[owner_id]['bots'].append(bot)

            if bot['real_status'] == 'running':
                users_map[owner_id]['sort_priority'] = 1
            elif users_map[owner_id]['sort_priority'] != 1:
                users_map[owner_id]['sort_priority'] = 2

    sorted_users = sorted(
        all_users, 
        key=lambda x: (x['sort_priority'], -x['tg_user_id'])
    )
    
    USERS_CACHE = {
        "data": sorted_users,
        "timestamp": current_time
    }
    
    return sorted_users

async def _generate_users_page_text(users_on_page: list) -> str:
    if not users_on_page:
        return "В этой категории нет пользователей."

    lines = []
    for user in users_on_page:
        user_id = user['tg_user_id']
        username = f"@{user['username']}" if user.get('username') else "Без юзернейма"
        full_name = html.quote(user.get('full_name', 'Name'))
        
        header = f"👤 <b>{full_name}</b> ({username}) <code>{user_id}</code>"
        
        bots_lines = []
        if user['bots']:
            for bot in user['bots']:
                status_icon = "🟢" if bot.get('real_status') == 'running' else "🔴"
                ub_type = bot.get('ub_type', 'unknown').capitalize()
                server_info = f"{bot.get('server_flag', '')} {bot.get('server_code', '')}"
                
                bot_line = (
                    f"   └ {status_icon} <b>{bot['ub_username']}</b> ({ub_type}) "
                    f"| {server_info}"
                )
                bots_lines.append(bot_line)
        else:
            bots_lines.append("   └ ⚪️ <i>Нет юзерботов</i>")

        if user.get('note'):
            bots_lines.append(f"   └ 📝 <i>{html.quote(user['note'])}</i>")

        lines.append(header + "\n" + "\n".join(bots_lines))

    return "\n\n".join(lines)

async def _get_paginated_users_text_and_markup(bot: Bot, view_mode: str, page: int, force_refresh=False):
    page_size = 7
    
    if view_mode == "visible":
        user_list = await _get_users_data_with_status(force_refresh=force_refresh)
        header = "<b>👥 Список пользователей (Docker Monitoring)</b>\n\n"
    else:
        user_list = await db.get_all_unregistered_users()
        for u in user_list:
            u['bots'] = []
        header = "<b>👻 Список скрытых пользователей (не приняли соглашение)</b>\n\n"

    total_items = len(user_list)
    total_pages = max(1, (total_items + page_size - 1) // page_size)
    page = max(1, min(page, total_pages))

    start_index = (page - 1) * page_size
    end_index = start_index + page_size
    users_on_page = user_list[start_index:end_index]

    text_body = await _generate_users_page_text(users_on_page)
    
    stats_line = f"\n\n📊 <b>Всего:</b> {total_items} | <b>Стр:</b> {page}/{total_pages}"
    full_text = header + text_body + stats_line

    markup = kb.get_user_list_paginator(page, total_pages, view_mode)

    return full_text, markup

@router.message(Command("users"), IsAdmin())
async def cmd_users_list(message: types.Message, bot: Bot):
    msg = await message.reply("⏳ <b>Обновляю данные с кластера...</b>")
    try:
        text, markup = await _get_paginated_users_text_and_markup(bot, view_mode="visible", page=1, force_refresh=True)
        await msg.edit_text(text=text, reply_markup=markup)
    except Exception as e:
        logging.error(f"Error in /users: {e}", exc_info=True)
        await msg.edit_text(f"❌ Произошла ошибка при сборе данных: {e}")

@router.callback_query(F.data.startswith("user_page:"), IsAdmin())
async def user_list_paginator_handler(call: types.CallbackQuery, bot: Bot):
    try:
        await call.answer()
    except:
        pass
        
    _, view_mode, page_str = call.data.split(':')
    page = int(page_str)
    
    text, markup = await _get_paginated_users_text_and_markup(bot, view_mode=view_mode, page=page, force_refresh=False)
    
    try:
        await call.message.edit_text(text=text, reply_markup=markup)
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Error pagination: {e}")

@router.callback_query(F.data.startswith("user_view_toggle:"), IsAdmin())
async def toggle_user_visibility_handler(call: types.CallbackQuery, bot: Bot):
    try:
        await call.answer("Переключение режима...")
    except:
        pass
        
    new_view_mode = call.data.split(':')[1]
    text, markup = await _get_paginated_users_text_and_markup(bot, view_mode=new_view_mode, page=1, force_refresh=False)
    await call.message.edit_text(text=text, reply_markup=markup)


@router.callback_query(F.data.startswith("host_reboot_confirm:"))
async def cq_host_reboot_confirm(call: types.CallbackQuery, bot: Bot):
    ip = call.data.split(":")[1]
    await call.message.edit_text(f"⏳ Перезагружаю сервер <code>{ip}</code>... Бот будет ожидать его возвращения в сеть.", reply_markup=None)

    await call.answer("Команда на перезагрузку отправлена.")

    asyncio.create_task(monitor_and_restore_server(ip, bot, call.from_user.id))


@router.callback_query(F.data == "host_reboot_cancel")
async def cq_host_reboot_cancel(call: types.CallbackQuery):
    await call.message.edit_text("🚫 Перезагрузка сервера отменена.")
    await call.answer()


async def monitor_and_restore_server(ip: str, bot: Bot, admin_id: int):
    await log_to_channel(bot, f"👀 Начал мониторинг сервера <code>{ip}</code>. Ожидаю, пока он уйдет в оффлайн...")


@router.message(Command("ban"), IsSuperAdmin())
async def cmd_ban(message: types.Message, command: CommandObject, bot: Bot):
    if message.message_thread_id and not command.args:
        await message.reply("<b>Использование:</b> <code>/ban [ID или @username]</code>\n<i>В треде необходимо указать пользователя аргументом.</i>")
        return
    elif not message.message_thread_id and not command.args and not message.reply_to_message:
        await message.reply("<b>Использование:</b> <code>/ban [ID или @username]</code>\n<i>Либо ответьте на сообщение пользователя.</i>")
        return

    target_id = None
    identifier_for_log = None
    is_in_db = False
    target_user_data = None

    if message.message_thread_id:
        if not command.args:
            await message.reply("❌ В треде необходимо указать пользователя аргументом.")
            return

        identifier = command.args.strip()
        identifier_for_log = identifier

        user_in_db = await db.get_user_by_username_or_id(identifier)
        if user_in_db:
            target_id = user_in_db['tg_user_id']
            target_user_data = {
                "id": target_id,
                "username": user_in_db.get('username'),
                "full_name": user_in_db.get('full_name')}
            is_in_db = True
        else:
            clean_id = identifier.lstrip('@')
            if clean_id.isdigit():
                target_id = int(clean_id)
                target_user_data = {
                    "id": target_id,
                    "full_name": f"ID: {target_id}"}
                is_in_db = False
            else:
                await message.reply(f"❌ Пользователь <code>{html.quote(identifier)}</code> не найден в БД, для бана укажите его ID.")
                return
    else:
        if message.reply_to_message:
            user = message.reply_to_message.from_user
            target_id = user.id
            identifier_for_log = f"@{user.username}" if user.username else str(
                user.id)
            target_user_data = {
                "id": user.id,
                "username": user.username,
                "full_name": user.full_name}
            is_in_db = bool(await db.get_user_data(target_id))
        else:
            identifier = command.args.strip()
            identifier_for_log = identifier

            user_in_db = await db.get_user_by_username_or_id(identifier)
            if user_in_db:
                target_id = user_in_db['tg_user_id']
                target_user_data = {
                    "id": target_id,
                    "username": user_in_db.get('username'),
                    "full_name": user_in_db.get('full_name')}
                is_in_db = True
            else:
                clean_id = identifier.lstrip('@')
                if clean_id.isdigit():
                    target_id = int(clean_id)
                    target_user_data = {
                        "id": target_id, "full_name": f"ID: {target_id}"}
                    is_in_db = False
                else:
                    await message.reply(f"❌ Пользователь <code>{html.quote(identifier)}</code> не найден в БД, для бана укажите его ID.")
                    return

    if not target_id:
        await message.reply("❌ Не удалось определить ID пользователя.")
        return

    if target_id == message.from_user.id:
        await message.reply("Вы не можете забанить себя.")
        return

    if await db.is_user_banned(target_id):
        await message.reply("Этот пользователь уже забанен.")
        return

    await ban_manager.execute_ban(target_user_data, message.from_user, bot, identifier_for_log, is_in_db)

    await message.reply(f"✅ Пользователь <code>{html.quote(identifier_for_log)}</code> заблокирован.")


@router.message(Command("unban"), IsSuperAdmin())
async def cmd_unban(message: types.Message, command: CommandObject, bot: Bot):
    if not command.args:
        if message.message_thread_id:
            await message.reply("Использование: <code>/unban [ID или @username]</code>\n<i>В треде необходимо указать пользователя аргументом.</i>")
        else:
            await message.reply("Использование: <code>/unban [ID или @username]</code>")
        return

    target_user_data = await db.get_user_by_username_or_id(command.args)
    if not target_user_data:
        await message.reply(f"❌ Пользователь <code>{html.quote(command.args)}</code> не найден в базе данных.")
        return

    target_user_id = target_user_data['tg_user_id']
    if not await db.is_user_banned(target_user_id):
        await message.reply("Этот пользователь не забанен.")
        return

    await ban_manager.execute_unban(target_user_id, message.from_user, bot)
    await message.reply(f"✅ Пользователь <code>{target_user_id}</code> разбанен.")


async def create_backup(backup_path: str, source_dir: str) -> bool:
    try:
        shutil.make_archive(backup_path, 'zip', source_dir)
        return True
    except Exception as e:
        logging.error(f"Ошибка при создании архива: {e}")
        return False


@router.message(Command("backup_bot"), IsSuperAdmin())
async def cmd_backup_bot_script(message: types.Message, bot: Bot):
    script_path = "./backup_bot.sh"

    if not os.path.exists(script_path):
        await message.reply(f"❌ <b>Ошибка:</b> Скрипт <code>{script_path}</code> не найден.")
        return

    msg = await message.reply("⏳ Начинаю процесс резервного копирования...\n\n📁 Архивирование исходного кода\n🗄️ Создание дампа базы данных\n📦 Формирование полного архива")
    archive_path = None

    try:
        logging.info(f"Запуск скрипта: {script_path}")
        process = await asyncio.create_subprocess_shell(
            script_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        stdout, stderr = await process.communicate()
        logging.info(f"Скрипт завершен с кодом: {process.returncode}")

        if process.returncode == 0:
            archive_path = stdout.decode().strip()
            logging.info(f"Скрипт вернул путь: '{archive_path}'")
            logging.info(f"stderr: '{stderr.decode().strip()}'")

            if not archive_path or not os.path.exists(archive_path):
                logging.error(f"Архив не найден по пути: '{archive_path}'")
                await msg.edit_text("❌ <b>Ошибка:</b> Скрипт выполнен, но не вернул путь к архиву.")
                return

            file_size = os.path.getsize(archive_path)
            file_size_mb = file_size / (1024 * 1024)

            await msg.edit_text("✅ Резервное копирование завершено!\n\n📊 <b>Информация об архиве:</b>\n📁 Размер: {:.1f} MB\n📅 Создан: {}\n\n📤 Отправляю файл суперадминистраторам...".format(
                file_size_mb,
                datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            ))

            document_to_send = FSInputFile(archive_path)
            caption_text = f"🗂️ <b>Полная резервная копия</b>\n\n📁 <b>Содержимое:</b>\n• Исходный код проекта\n• Дамп базы данных MySQL\n\n📅 Создан: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n📊 Размер: {file_size_mb:.1f} MB"

            success_count = 0
            for admin_id in config.SUPER_ADMIN_IDS:
                try:
                    await bot.send_document(
                        chat_id=admin_id,
                        document=document_to_send,
                        caption=caption_text
                    )
                    success_count += 1
                    await asyncio.sleep(0.5)
                except Exception as e:
                    logging.error(
                        f"Не удалось отправить бэкап администратору {admin_id}: {e}")

            await msg.delete()
            await message.answer(f"✅ <b>Резервное копирование завершено!</b>\n\n📤 Отправлено администраторам: {success_count}/{len(config.SUPER_ADMIN_IDS)}\n📊 Размер архива: {file_size_mb:.1f} MB\n\n🗂️ <b>Архив содержит:</b>\n• Исходный код проекта\n• Полный дамп базы данных MySQL")

        else:
            error_output = stderr.decode().strip()
            logging.error(f"Ошибка выполнения backup_bot.sh: {error_output}")
            await msg.edit_text(f"❌ <b>Ошибка при создании бэкапа:</b>\n<pre>{html.quote(error_output)}</pre>")

    except Exception as e:
        logging.error(
            f"Критическая ошибка в cmd_backup_bot_script: {e}",
            exc_info=True)
        await msg.edit_text(f"❌ <b>Произошла критическая ошибка:</b>\n<pre>{html.quote(str(e))}</pre>")
    finally:
        if archive_path and os.path.exists(archive_path):
            os.remove(archive_path)


async def auto_backup_task(bot: Bot):
    if config.TEST_MODE:
        logging.info("Test mode enabled, skipping auto backup task")
        return

    logging.info("🔄 Запуск автоматического резервного копирования...")

    script_path = "./backup_bot.sh"
    if not os.path.exists(script_path):
        logging.error(
            f"❌ Скрипт {script_path} не найден для автоматического бэкапа")
        return

    archive_path = None
    try:
        process = await asyncio.create_subprocess_shell(
            script_path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        stdout, stderr = await process.communicate()

        if process.returncode == 0:
            archive_path = stdout.decode().strip()
            if not archive_path or not os.path.exists(archive_path):
                logging.error(
                    "❌ Автоматический бэкап: скрипт выполнен, но не вернул путь к архиву")
                return

            file_size = os.path.getsize(archive_path)
            file_size_mb = file_size / (1024 * 1024)

            logging.info(
                f"✅ Автоматический бэкап создан: {archive_path} ({file_size_mb:.1f} MB)")

            document_to_send = FSInputFile(archive_path)
            caption_text = f"🔄 <b>Автоматическая резервная копия</b>\n\n📁 <b>Содержимое:</b>\n• Исходный код проекта\n• Дамп базы данных MySQL\n\n📅 Создан: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n📊 Размер: {file_size_mb:.1f} MB\n\n⏰ <i>Создано автоматически каждые 30 минут</i>"

            success_count = 0
            for admin_id in config.SUPER_ADMIN_IDS:
                try:
                    await bot.send_document(
                        chat_id=admin_id,
                        document=document_to_send,
                        caption=caption_text
                    )
                    success_count += 1
                    await asyncio.sleep(0.5)
                except Exception as e:
                    logging.error(
                        f"Не удалось отправить автоматический бэкап администратору {admin_id}: {e}")

            logging.info(
                f"✅ Автоматический бэкап отправлен {success_count}/{len(config.SUPER_ADMIN_IDS)} администраторам")

        else:
            error_output = stderr.decode().strip()
            logging.error(f"❌ Ошибка автоматического бэкапа: {error_output}")

    except Exception as e:
        logging.error(
            f"❌ Критическая ошибка в auto_backup_task: {e}",
            exc_info=True)
    finally:
        if archive_path and os.path.exists(archive_path):
            os.remove(archive_path)
            logging.info(f"🗑️ Автоматический бэкап удален: {archive_path}")


@router.message(Command("git"), IsSuperAdmin())
async def cmd_git_manager(message: types.Message, command: CommandObject):
    if not command.args:
        help_text = (
            "<b>⚙️ Управление Git-репозиторием</b>\n\n"
            "<code>/git status</code>\n"
            "<i>- Проверить текущий статус.</i>\n\n"
            "<code>/git add &lt;файл1&gt; [файл2]...</code>\n"
            "<i>- Добавить файлы в следующий коммит.</i>\n\n"
            "<code>/git commit -m \"&lt;сообщение&gt;\"</code>\n"
            "<i>- Зафиксировать изменения.</i>\n\n"
            "<code>/git push</code>\n"
            "<i>- Отправить изменения на сервер.</i>"
        )
        await message.reply(help_text)
        return

    try:
        args = shlex.split(command.args)
    except ValueError:
        await message.reply("❌ <b>Ошибка:</b> Некорректное экранирование в команде.")
        return

    action = args[0].lower() if args else None

    if action == "add":
        if len(args) < 2:
            await message.reply("<b>Ошибка:</b> Укажите один или несколько файлов.\nПример: <code>/git add app.py</code>")
            return

        files_to_add = args[1:]

        valid_filename_pattern = re.compile(r"^[a-zA-Z0-9._/-]+$")
        sanitized_files = []
        for f in files_to_add:
            if ".." in f or not valid_filename_pattern.match(f):
                await message.reply(f"<b>Ошибка:</b> Недопустимое имя файла: <code>{html.quote(f)}</code>")
                return
            if not os.path.exists(f):
                await message.reply(f"<b>Ошибка:</b> Файл не найден: <code>{html.quote(f)}</code>")
                return
            sanitized_files.append(shlex.quote(f))

        git_command = f"git add {' '.join(sanitized_files)}"

        msg = await message.reply(f"⏳ Выполняю: <code>{html.quote(git_command)}</code>...")
        res = await sm.run_command_async(git_command, sm.LOCAL_IP)

        if res["success"]:
            await msg.edit_text("✅ Файлы успешно добавлены в индекс.")
        else:
            error_output = res.get('error') or res.get(
                'output', 'Неизвестная ошибка Git.')
            await msg.edit_text(f"❌ <b>Ошибка при добавлении:</b>\n<pre>{html.quote(error_output)}</pre>")

    elif action == "commit":
        if len(args) < 3 or args[1] != '-m':
            await message.reply('<b>Ошибка:</b> Неверный формат.\nИспользуйте: <code>/git commit -m "Ваш текст"</code>')
            return

        commit_message = args[2]
        git_command = f"git commit -m {shlex.quote(commit_message)}"

        msg = await message.reply("⏳ Создаю коммит...")
        res = await sm.run_command_async(git_command, sm.LOCAL_IP)

        if res["success"]:
            output = res.get('output', 'Коммит успешно создан.')
            await msg.edit_text(f"✅ <b>Коммит создан:</b>\n<pre>{html.quote(output)}</pre>")
        else:
            error_output = res.get('error') or res.get(
                'output', 'Неизвестная ошибка Git.')
            await msg.edit_text(f"❌ <b>Ошибка при создании коммита:</b>\n<pre>{html.quote(error_output)}</pre>")

    elif action == "push":
        msg = await message.reply("⏳ Выполняю <code>git push origin main --force</code>...")

        git_command = "git push origin main --force"
        res = await sm.run_command_async(git_command, sm.LOCAL_IP, timeout=180)

        if res["success"]:
            output = res.get('output') or res.get(
                'error', 'Push выполнен, но Git не вернул вывод.')
            await msg.edit_text(f"✅ <b>Push выполнен успешно.</b>\n\n<pre>{html.quote(output)}</pre>")
        else:
            error_output = res.get('error') or res.get(
                'output', 'Неизвестная ошибка Git.')
            await msg.edit_text(f"❌ <b>Ошибка во время push:</b>\n\n<pre>{html.quote(error_output)}</pre>")

    elif action == "status":
        msg = await message.reply("⏳ Получаю статус Git...")
        res = await sm.run_command_async("git status", sm.LOCAL_IP)
        if res["success"]:
            output = res.get('output', 'Git не вернул вывод.')
            await msg.edit_text(f"<b>Статус репозитория:</b>\n<pre>{html.quote(output)}</pre>")
        else:
            error_output = res.get('error') or res.get(
                'output', 'Неизвестная ошибка.')
            await msg.edit_text(f"❌ <b>Ошибка получения статуса:</b>\n<pre>{html.quote(error_output)}</pre>")

    else:
        await message.reply(f"Неизвестная команда '<code>{action}</code>'. Используйте <code>/git</code> для справки.")


@router.callback_query(F.data == "reject_review", IsAdmin())
async def cq_reject_review(call: types.CallbackQuery):
    try:
        if call.message.reply_to_message:
            await call.bot.delete_message(
                chat_id=call.message.chat.id,
                message_id=call.message.reply_to_message.message_id
            )
    except Exception as e:
        logging.warning(
            f"Не удалось удалить пересланное сообщение при отклонении отзыва: {e}")

    await call.message.delete()
    await call.answer("Отзыв отклонен и удален.")


@router.callback_query(F.data.startswith("approve_review:"), IsAdmin())
async def cq_approve_review(call: types.CallbackQuery, bot: Bot):
    if not config.REVIEW_CHANNEL_ID:
        await call.answer("ID канала для отзывов не настроен в конфиге!", show_alert=True)
        return

    try:
        _, user_id_str, message_id_str = call.data.split(":")
        user_id = int(user_id_str)
        message_id = int(message_id_str)
    except ValueError:
        await call.answer("Ошибка в данных. Не удалось опубликовать.", show_alert=True)
        return

    await call.answer("Публикую отзыв...")

    try:
        await bot.forward_message(
            chat_id=config.REVIEW_CHANNEL_ID,
            from_chat_id=user_id,
            message_id=message_id
        )
        await call.message.edit_text("✅ Отзыв успешно опубликован!")
    except Exception as e:
        logging.error(f"Не удалось опубликовать отзыв от {user_id}: {e}")
        await call.message.edit_text(f"❌ Ошибка публикации: {e}")


async def _display_user_info_panel(bot: Bot, user_id: int, chat_id: int, message_id: int):
    user_data = await db.get_user_data(user_id)
    if not user_data:
        try:
            chat_info = await bot.get_chat(user_id)
            user_data = {
                "tg_user_id": chat_info.id,
                "full_name": chat_info.full_name,
                "username": chat_info.username}
        except (TelegramNotFound, TelegramBadRequest):
            await bot.edit_message_text(f"❌ Пользователь с ID <code>{user_id}</code> не найден.", chat_id=chat_id, message_id=message_id)
            return

    full_name = html.quote(user_data.get('full_name', 'Имя не указано'))
    username = user_data.get('username')

    user_bots = await db.get_userbots_by_tg_id(user_id)
    bot_count = len(user_bots)

    text_parts = [
        "ℹ️ <b>Информация о пользователе</b>\n",
        f"<b>Имя:</b> {full_name}",
    ]
    if username:
        text_parts.append(f"<b>Юзернейм:</b> @{html.quote(username)}")
    text_parts.append(f"<b>ID:</b> <code>{user_id}</code>")
    text_parts.append("⎯⎯⎯⎯⎯⎯⎯⎯⎯⎯")
    text_parts.append(f"<b>Юзерботы:</b> {bot_count}")

    text = "\n".join(text_parts)
    markup = kb.get_user_info_keyboard(user_id, has_bots=bool(user_bots))

    try:
        await bot.edit_message_text(text, chat_id=chat_id, message_id=message_id, reply_markup=markup)
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Ошибка редактирования панели пользователя: {e}")


async def _get_target_user_data(message: types.Message, command: CommandObject, bot: Bot):
    identifier = None

    if command.args:
        arg = command.args.strip().rstrip(',').lstrip('@')

        ub_data = await db.get_userbot_data(ub_username=arg)
        if ub_data:
            identifier = str(ub_data['tg_user_id'])
        else:
            identifier = arg

    elif message.reply_to_message:
        identifier = str(message.reply_to_message.from_user.id)

    else:

        return None, "<b>Ошибка:</b> Укажите пользователя (ID, @username, имя юзербота) или ответьте на его сообщение."

    user_data = await db.get_user_by_username_or_id(identifier)

    if user_data:
        return user_data, None

    if identifier.isdigit():
        try:
            chat_info = await bot.get_chat(int(identifier))

            return {
                "tg_user_id": chat_info.id,
                "full_name": chat_info.full_name,
                "username": chat_info.username,
                "note": None
            }, None
        except (TelegramNotFound, TelegramBadRequest):
            return None, f"❌ Пользователь с ID <code>{html.quote(identifier)}</code> не найден."

    return None, f"❌ Не удалось найти пользователя по идентификатору: <code>{html.quote(identifier)}</code>"


@router.message(Command("user"), IsAdmin())
async def cmd_user_info(message: types.Message, command: CommandObject, bot: Bot):
    msg = await message.reply("⏳ Ищу пользователя...")
    user_data, error_message = await _get_target_user_data(message, command, bot)

    if error_message:
        await msg.edit_text(error_message)
        return

    await _display_user_info_panel(bot, user_data['tg_user_id'], msg.chat.id, msg.message_id)


async def _display_admin_ub_management_panel(call: types.CallbackQuery, bot: Bot, ub_username: str, user_id: int):
    ub_data = await db.get_userbot_data(ub_username)
    owner_data = await db.get_user_data(user_id)

    if not ub_data or not owner_data:
        await call.answer("❌ Не удалось найти данные. Возможно, юзербот был удален.", show_alert=True)
        return

    server_ip = ub_data.get('server_ip')
    servers = server_config.get_servers()
    server_details = servers.get(server_ip, {})
    server_code = server_details.get("code", "N/A")

    is_active = False
    container_status = await api_manager.get_container_status(ub_username, server_ip)
    if not container_status.get("success"):
        error_msg = container_status.get("error", "Неизвестная ошибка")
        if "404" in error_msg or "not found" in error_msg.lower():
            user_info_for_log = {
                "id": user_id, "full_name": owner_data.get(
                    "full_name", str(user_id))}
            log_data = {
                "user_data": user_info_for_log,
                "ub_info": {"name": ub_username},
                "server_info": {"ip": server_ip, "code": server_code},
                "error": error_msg
            }
            asyncio.create_task(
                log_event(
                    bot,
                    "api_container_error",
                    log_data))
    else:
        is_active = container_status.get("data", {}).get("status") == "running"

    server_flag = server_details.get("flag", "🏳️")
    server_location = f"{server_details.get('country', 'N/A')}, {server_details.get('city', 'N/A')}"

    ping_ms_val = await api_manager.get_server_ping(server_ip)

    resources = {
        'cpu_percent': 0.0, 'ram_percent': 0.0, 'ram_used': 0, 'ram_limit': 0,
        'disk_percent': 0.0, 'disk_used': 0, 'disk_limit': 0
    }

    if is_active:
        stats_result = await api_manager.get_container_stats(ub_username, server_ip)
        if stats_result.get("success"):
            info = stats_result.get("data", {}).get("info", {})
            if info:
                resources['cpu_percent'] = round(info.get("cpu_percent") or 0.0, 1)
                resources['ram_used'] = round(info.get("ram_usage_mb") or 0)
                resources['ram_limit'] = round(info.get("ram_limit_mb") or 0)
                resources['ram_percent'] = round(info.get("ram_percent") or 0.0, 1)
                resources['disk_used'] = round(info.get("disk_usage_mb") or 0)
                resources['disk_limit'] = round(info.get("disk_limit_mb") or 0)
                resources['disk_percent'] = round(info.get("disk_percent") or 0.0, 1)

    status_text = "🟢 Включен" if is_active else "🔴 Выключен"
    ping_display = f"📡 Пинг: {ping_ms_val:.1f} мс" if ping_ms_val is not None else "📡 Пинг: N/A"
    owner_username = f"@{owner_data['username']}" if owner_data.get(
        'username') else 'N/A'

    text_lines = [
        "<b>🎛️ Управление юзерботом</b>\n", "<blockquote expandable>"
        "<b>Основная информация:</b>\n"
        f"🤖 Юзербот: <code>{html.quote(ub_username)}</code>\n"
        f"👤 Владелец: {html.quote(owner_data.get('full_name', ''))} ({owner_username}, <code>{user_id}</code>)\n"
        f"💡 Статус: {status_text}\n"
        f"⚙️ Тип: {ub_data.get('ub_type', 'N/A').capitalize()}"
        "</blockquote>", "<blockquote expandable><b>Информация о сервере:</b>\n"
        f"🖥 Сервер: {server_flag} {server_code}\n"
        f"🌍 Локация: {server_location}\n"
        f"{ping_display}"
        "</blockquote>", "<blockquote expandable>"
        "<b>Потребление ресурсов:</b>\n"
        f"🧠 CPU: {create_progress_bar(str(resources.get('cpu_percent', 0)))} ({resources.get('cpu_percent', 0)}%)\n"
        f"💾 RAM: {create_progress_bar(str(resources.get('ram_percent', 0)))} ({resources.get('ram_used', 0)} / {resources.get('ram_limit', 0)} МБ)\n"
        f"💽 ROM: {create_progress_bar(str(resources.get('disk_percent', 0)))} ({resources.get('disk_used', 0)} / {resources.get('disk_limit', 0)} МБ)"
        "</blockquote>\n"]
    update_time_str = datetime.now(
        pytz.timezone("Europe/Moscow")).strftime('%H:%M:%S')
    text_lines.append(f"<i>Последнее обновление: {update_time_str} MSK</i>")
    text = "\n".join(text_lines)

    markup = kb.get_admin_ub_management_keyboard(
        ub_username, user_id, is_active)

    await call.message.edit_text(text, reply_markup=markup)


@router.callback_query(F.data.startswith("show_user_bots:"), IsAdmin())
async def cq_show_user_bots_list(call: types.CallbackQuery, bot: Bot):
    await call.message.edit_reply_markup(reply_markup=kb.get_admin_loading_keyboard())
    await call.answer()

    user_id = int(call.data.split(":")[1])
    user_bots = await db.get_userbots_by_tg_id(user_id)

    if not user_bots:
        text = "🤖 У этого пользователя нет юзерботов."
        markup = kb.get_user_bots_list_keyboard([], user_id)
        await call.message.edit_text(text, reply_markup=markup)
        return

    first_bot = user_bots[0]
    ub_username = first_bot['ub_username']

    await _display_admin_ub_management_panel(call, bot, ub_username, user_id)


@router.callback_query(F.data.startswith("select_user_bot:"), IsAdmin())
async def cq_select_user_bot_for_admin(call: types.CallbackQuery, bot: Bot):
    await call.message.edit_reply_markup(reply_markup=kb.get_admin_loading_keyboard())
    await call.answer()

    _, ub_username, user_id_str = call.data.split(":")
    user_id = int(user_id_str)

    await _display_admin_ub_management_panel(call, bot, ub_username, user_id)


@router.callback_query(F.data.startswith("back_to_user_info:"), IsAdmin())
async def cq_back_to_user_info(call: types.CallbackQuery, bot: Bot):
    await call.message.edit_reply_markup(reply_markup=kb.get_admin_loading_keyboard())
    await call.answer()
    user_id = int(call.data.split(":")[1])
    await _display_user_info_panel(bot, user_id, call.message.chat.id, call.message.message_id)


@router.callback_query(F.data.startswith("admin_manage_ub:"), IsAdmin())
async def cq_admin_manage_ub(call: types.CallbackQuery, bot: Bot):
    await call.message.edit_reply_markup(reply_markup=kb.get_admin_loading_keyboard())

    try:
        _, action, ub_username, user_id_str = call.data.split(":")
        user_id = int(user_id_str)
    except ValueError:
        await call.answer("Ошибка в данных, обновите панель.", show_alert=True)
        return

    await call.answer(f"Выполняю действие: {action}...")

    ub_data = await db.get_userbot_data(ub_username)
    if not ub_data:
        await call.answer("❌ Юзербот не найден.", show_alert=True)
        await _display_user_info_panel(bot, user_id, call.message.chat.id, call.message.message_id)
        return

    server_ip = ub_data['server_ip']
    result = None

    if action == "start":
        result = await api_manager.start_container(ub_username, server_ip)
    elif action == "stop":
        result = await api_manager.stop_container(ub_username, server_ip)
    elif action == "restart":
        result = await api_manager.restart_container(ub_username, server_ip)

    if not result or not result.get("success"):
        error_msg = result.get(
            'error', 'Неизвестная ошибка') if result else 'Нет ответа от API'
        try:
            await call.answer(f"❌ Ошибка: {error_msg[:150]}", show_alert=True)
        except TelegramBadRequest:
            pass

    await asyncio.sleep(1.5)

    await _display_admin_ub_management_panel(call, bot, ub_username, user_id)


@router.callback_query(F.data.startswith("admin_delete_ub:"), IsAdmin())
async def cq_admin_delete_ub(call: types.CallbackQuery):
    await call.message.edit_reply_markup(reply_markup=kb.get_admin_loading_keyboard())
    ub_username = call.data.split(":")[1]

    builder = InlineKeyboardBuilder()
    builder.button(
        text="✅ Да, удалить",
        callback_data=f"admin_delete_confirm:{ub_username}")
    builder.button(text="❌ Нет", callback_data=f"select_user_bot:{ub_username}:{await db.get_userbot_data(ub_username)['tg_user_id']}")

    await call.message.edit_text(
        f"Вы уверены, что хотите удалить юзербота <code>{html.quote(ub_username)}</code>?",
        reply_markup=builder.as_markup()
    )
    await call.answer()


@router.callback_query(F.data.startswith("admin_delete_confirm:"), IsAdmin())
async def cq_admin_delete_confirm(call: types.CallbackQuery, bot: Bot):
    await call.message.edit_text("⏳ Удаляю...", reply_markup=kb.get_admin_loading_keyboard())
    ub_username = call.data.split(":")[1]

    ub_data = await db.get_userbot_data(ub_username)
    if not ub_data:
        await call.message.edit_text("❌ Юзербот уже удален.")
        return

    user_id = ub_data['tg_user_id']

    # Удаляем контейнер через API
    delete_result = await api_manager.delete_container(ub_username, ub_data['server_ip'])

    if delete_result.get("success"):
        # Удаляем запись из базы данных
        await db.delete_userbot_record(ub_username)
        await call.message.edit_text(f"✅ Юзербот <code>{html.quote(ub_username)}</code> удален.")
    else:
        error_message = delete_result.get(
            'error', 'Произошла неизвестная ошибка.')
        await call.message.edit_text(f"❌ Ошибка при удалении: {html.quote(error_message)}")

    await asyncio.sleep(2)
    user_bots = await db.get_userbots_by_tg_id(user_id)
    markup = kb.get_user_bots_list_keyboard(user_bots, user_id)
    await call.message.edit_text("🤖 **Юзерботы пользователя:**", reply_markup=markup)


@router.callback_query(F.data.startswith("admin_show_logs:"), IsAdmin())
async def cq_admin_show_logs(call: types.CallbackQuery, bot: Bot):
    await call.message.edit_reply_markup(reply_markup=kb.get_admin_loading_keyboard())
    await call.answer()

    _, log_type, ub_username, page_str = call.data.split(":")
    page = int(page_str)

    ub_data = await db.get_userbot_data(ub_username)
    if not ub_data:
        await call.answer("❌ Юзербот не найден.", show_alert=True)
        return

    # Используем API для получения логов контейнера
    logs_result = await api_manager.get_container_logs(ub_username, ub_data['server_ip'])

    if logs_result.get("success"):
        logs_data = logs_result.get("data", {})
        logs = logs_data.get("logs", "")
    else:
        error_msg = logs_result.get('error', 'Неизвестная ошибка')
        if "No such container" in error_msg or "404" in error_msg:
            logs = f"❌ Контейнер {ub_username} не найден на сервере"
        else:
            logs = f"❌ Ошибка получения логов: {error_msg}"

    if not logs:
        await call.answer("📜 Логи для этого юзербота пусты.", show_alert=True)
        is_active = False # Simplified logic
        markup = kb.get_admin_ub_management_keyboard(
            ub_username, ub_data['tg_user_id'], is_active)
        await call.message.edit_reply_markup(reply_markup=markup)
        return

    log_lines = logs.strip().split('\n')
    total_pages = max(
        1,
        (len(log_lines) +
         LOG_LINES_PER_PAGE -
         1) //
        LOG_LINES_PER_PAGE)
    page = max(1, min(page, total_pages))
    start_index = (page - 1) * LOG_LINES_PER_PAGE
    end_index = start_index + LOG_LINES_PER_PAGE
    page_content = "\n".join(log_lines[start_index:end_index])

    text = (
        f"📜 <b>Логи ({log_type.capitalize()}) для <code>{html.quote(ub_username)}</code></b>\n"
        f"<i>(Стр. {page}/{total_pages}, новые логи сверху)</i>\n\n"
        f"<pre>{html.quote(page_content)}</pre>")

    if len(text) > 4096:
        text = text[:4090] + "...</pre>"

    markup = kb.get_admin_logs_paginator_keyboard(
        log_type, ub_username, ub_data['tg_user_id'], page, total_pages)
    await call.message.edit_text(text, reply_markup=markup)


@router.callback_query(F.data.startswith("admin_transfer_start:"), IsAdmin())
async def cq_admin_start_transfer(call: types.CallbackQuery, state: FSMContext):
    ub_username = call.data.split(":")[1]
    ub_data = await db.get_userbot_data(ub_username)
    if not ub_data:
        await call.answer("❌ Юзербот не найден.", show_alert=True)
        return

    await state.set_state(AdminUserBotTransfer.WaitingForNewOwnerID)
    await state.update_data(
        ub_username=ub_username,
        message_id_to_edit=call.message.message_id,
        original_owner_id=ub_data['tg_user_id']
    )

    text = f"Введите ID нового владельца для юзербота <code>{html.quote(ub_username)}</code>."
    markup = kb.get_admin_cancel_transfer_keyboard(ub_username)
    await call.message.edit_text(text, reply_markup=markup)
    await call.answer()


@router.callback_query(F.data.startswith("admin_transfer_cancel:"),
                       StateFilter(AdminUserBotTransfer.WaitingForNewOwnerID,
                                   AdminUserBotTransfer.ConfirmingTransfer))
async def cq_admin_cancel_transfer(call: types.CallbackQuery, state: FSMContext):
    await call.answer("Перенос отменен.")
    data = await state.get_data()
    ub_username = data['ub_username']
    user_id = data['original_owner_id']
    await state.clear()

    is_active = False
    owner_data = await db.get_user_data(user_id)
    owner_username = f"@{owner_data['username']}" if owner_data.get(
        'username') else 'N/A'

    text = (
        f"<b>Управление:</b> <code>{html.quote(ub_username)}</code>\n"
        f"<b>Владелец:</b> {html.quote(owner_data.get('full_name', ''))} ({owner_username}, <code>{user_id}</code>)\n"
        f"<b>Тип:</b> {html.quote(await db.get_userbot_data(ub_username).get('ub_type', 'N/A').capitalize())}\n"
        f"<b>Сервер:</b> <code>{await db.get_userbot_data(ub_username).get('server_ip', 'N/A')}</code>"
    )
    markup = kb.get_admin_ub_management_keyboard(
        ub_username, user_id, is_active)

    await call.message.edit_text(text, reply_markup=markup)


@router.message(StateFilter(AdminUserBotTransfer.WaitingForNewOwnerID))
async def msg_admin_process_new_owner_id(message: types.Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    ub_username = data.get("ub_username")
    message_id_to_edit = data.get("message_id_to_edit")

    await message.delete()

    if not message.text or not message.text.isdigit():
        await bot.edit_message_text("❌ ID пользователя должен быть числом. Попробуйте снова.", chat_id=message.chat.id, message_id=message_id_to_edit, reply_markup=kb.get_admin_cancel_transfer_keyboard(ub_username))
        return

    new_owner_id = int(message.text)

    await bot.edit_message_text("⏳ Проверяю пользователя...", chat_id=message.chat.id, message_id=message_id_to_edit)

    try:
        new_owner = await bot.get_chat(new_owner_id)
        new_owner_display = f"@{new_owner.username}" if new_owner.username else new_owner.full_name

        await state.update_data(new_owner_id=new_owner_id)
        await state.set_state(AdminUserBotTransfer.ConfirmingTransfer)

        text = f"Вы точно хотите передать юзербота <code>{html.quote(ub_username)}</code> пользователю {html.quote(new_owner_display)} (<code>{new_owner_id}</code>)?"
        markup = kb.get_admin_confirm_transfer_keyboard(
            ub_username, new_owner_id)
        await bot.edit_message_text(text, chat_id=message.chat.id, message_id=message_id_to_edit, reply_markup=markup)

    except (TelegramNotFound, TelegramBadRequest):
        await bot.edit_message_text(f"❌ Пользователь с ID <code>{new_owner_id}</code> не найден. Проверьте ID и попробуйте снова.", chat_id=message.chat.id, message_id=message_id_to_edit, reply_markup=kb.get_admin_cancel_transfer_keyboard(ub_username))
        await state.set_state(AdminUserBotTransfer.WaitingForNewOwnerID)


@router.callback_query(F.data.startswith("admin_transfer_execute:"),
                       StateFilter(AdminUserBotTransfer.ConfirmingTransfer))
async def cq_admin_execute_transfer(call: types.CallbackQuery, state: FSMContext, bot: Bot):
    await call.message.edit_reply_markup(reply_markup=kb.get_admin_loading_keyboard())

    data = await state.get_data()
    ub_username = data['ub_username']
    original_owner_id = data['original_owner_id']
    new_owner_id = data['new_owner_id']

    if not await db.transfer_userbot(ub_username, new_owner_id):
        await call.answer("❌ Произошла ошибка при обновлении базы данных.", show_alert=True)
        is_active = False
        markup = kb.get_admin_ub_management_keyboard(
            ub_username, original_owner_id, is_active)
        await call.message.edit_reply_markup(reply_markup=markup)
        return

    try:
        admin_data = {
            "id": call.from_user.id,
            "full_name": call.from_user.full_name}
        old_owner_chat = await bot.get_chat(original_owner_id)
        new_owner_chat = await bot.get_chat(new_owner_id)
        log_data = {
            "admin_data": admin_data,
            "user_data": {
                "id": old_owner_chat.id,
                "full_name": old_owner_chat.full_name},
            "new_owner_data": {
                "id": new_owner_chat.id,
                "full_name": new_owner_chat.full_name},
            "ub_info": {
                "name": ub_username}}
        await log_event(bot, "userbot_transferred", log_data)
    except Exception as e:
        logging.error(f"Не удалось залогировать админский перенос UB: {e}")

    await state.clear()
    await call.message.edit_text("✅ Перенос успешно завершен.")

    try:
        await bot.send_message(
            chat_id=new_owner_id,
            text=f"Администратор передал вам юзербота <code>{html.quote(ub_username)}</code>.\n\n"
                 "Вы можете управлять им, отправив команду /start."
        )
    except TelegramForbiddenError:
        logging.warning(
            f"Не удалось уведомить нового владельца {new_owner_id}: пользователь не начал диалог с ботом")
    except Exception as e:
        logging.error(
            f"Не удалось уведомить нового владельца {new_owner_id}: {e}")


@router.message(Command("set_api_token"), IsSuperAdmin())
async def cmd_set_api_token(message: types.Message, command: CommandObject):
    if not command.args:
        help_text = (
            "<b>Использование:</b> <code>/set_api_token [IP] [токен]</code>\n\n"
            "<b>Примеры:</b>\n"
            "• <code>/set_api_token 13.60.199.97 kivWJm0e2ey9u50uCqEwCIcHstCwuZslu7QK4YcEsCTGQcUTx33JC3bZve0zvr8y</code>\n"
            "• <code>/set_api_token 62.84.121.74 новый_токен_здесь</code>")
        await message.reply(help_text)
        return

    args = command.args.split()
    if len(args) < 2:
        await message.reply("❌ Недостаточно аргументов. Используйте: <code>/set_api_token [IP] [токен]</code>")
        return

    ip = args[0]
    token = args[1]

    servers = server_config.get_servers()
    if ip not in servers:
        await message.reply(f"❌ Сервер <code>{ip}</code> не найден в конфигурации.")
        return

    success = server_config.set_server_api_token(ip, token)
    if success:
        await message.reply(f"✅ API токен для сервера <code>{ip}</code> успешно обновлен.")
    else:
        await message.reply(f"❌ Ошибка при обновлении токена для сервера <code>{ip}</code>.")


@router.message(Command("set_api_url"), IsSuperAdmin())
async def cmd_set_api_url(message: types.Message, command: CommandObject):
    if not command.args:
        help_text = (
            "<b>Использование:</b> <code>/set_api_url [IP] [URL]</code>\n\n"
            "<b>Примеры:</b>\n"
            "• <code>/set_api_url 13.60.199.97 http://s1.mdkadmin.online:8000</code>\n"
            "• <code>/set_api_url 62.84.121.74 http://m7.mdkadmin.online:8000</code>")
        await message.reply(help_text)
        return

    args = command.args.split()
    if len(args) < 2:
        await message.reply("❌ Недостаточно аргументов. Используйте: <code>/set_api_url [IP] [URL]</code>")
        return

    ip = args[0]
    url = args[1]

    servers = server_config.get_servers()
    if ip not in servers:
        await message.reply(f"❌ Сервер <code>{ip}</code> не найден в конфигурации.")
        return

    success = server_config.set_server_api_url(ip, url)
    if success:
        await message.reply(f"✅ API URL для сервера <code>{ip}</code> успешно обновлен: <code>{url}</code>")
    else:
        await message.reply(f"❌ Ошибка при обновлении URL для сервера <code>{ip}</code>.")


async def _send_api_config_page(message: types.Message, page: int = 1, is_edit: bool = False):
    servers = list(server_config.get_servers().items())

    if not servers:
        text = "<blockquote>❌ Нет настроенных серверов.</blockquote>"
        if is_edit:
            await message.edit_text(text, reply_markup=None)
        else:
            await message.reply(text)
        return

    total_pages = math.ceil(len(servers) / API_CONFIG_PAGE_SIZE)
    page = max(1, min(page, total_pages))

    start_index = (page - 1) * API_CONFIG_PAGE_SIZE
    end_index = start_index + API_CONFIG_PAGE_SIZE
    servers_on_page = servers[start_index:end_index]

    header = "🔧 <b>API Конфигурация серверов</b>"

    server_blocks = []
    for ip, config in servers_on_page:
        api_url = server_config.get_server_api_url(ip) or '<i>не настроен</i>'
        api_token = server_config.get_server_api_token(ip)

        token_display = f"<code>{api_token[:8]}...</code>" if api_token and api_token != '<i>не настроен</i>' else '<i>не настроен</i>'

        server_block = (
            f"<b>{config.get('flag', '🏳️')} {config.get('name', ip)}</b> (<code>{ip}</code>)\n"
            f"  <b>URL:</b> <code>{api_url}</code>\n"
            f"  <b>Token:</b> {token_display}")
        server_blocks.append(server_block)

    content = "\n\n".join(server_blocks)
    pagination_info = f"\n\n<i>📄 Страница {page} из {total_pages}</i>" if total_pages > 1 else ""

    text = f"<blockquote>{header}\n\n{content}{pagination_info}</blockquote>"

    markup = kb.get_api_config_paginator_keyboard(
        page, total_pages) if total_pages > 1 else None

    try:
        if is_edit:
            await message.edit_text(text, reply_markup=markup)
        else:
            await message.reply(text, reply_markup=markup)
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Ошибка при отправке страницы API конфига: {e}")


@router.message(Command("show_api_config"), IsSuperAdmin())
async def cmd_show_api_config(message: types.Message):
    await _send_api_config_page(message, page=1, is_edit=False)


@router.callback_query(F.data.startswith("api_config_page:"), IsSuperAdmin())
async def cq_api_config_page(call: types.CallbackQuery):
    await call.answer()
    try:
        page = int(call.data.split(":")[1])
        await _send_api_config_page(call.message, page=page, is_edit=True)
    except (ValueError, IndexError):
        await call.answer("Ошибка данных пагинации.", show_alert=True)


async def _generate_and_save_token(user: types.User) -> str:
    username = user.username or f"user{user.id}"
    random_part = secrets.token_hex(18)
    new_token = f"{username}:{user.id}:{random_part}"
    await db.set_api_token(user.id, new_token)
    return new_token


async def _send_servers_page(message: types.Message, page: int = 1, is_edit: bool = False):
    servers = list(server_config.get_servers().items())

    if not servers:
        text = "<blockquote expandable>❌ Нет настроенных серверов.</blockquote>"
        if is_edit:
            await message.edit_text(text, reply_markup=None)
        else:
            await message.reply(text)
        return

    total_pages = math.ceil(len(servers) / SERVERS_PAGE_SIZE)
    page = max(1, min(page, total_pages))

    start_index = (page - 1) * SERVERS_PAGE_SIZE
    end_index = start_index + SERVERS_PAGE_SIZE
    servers_on_page = servers[start_index:end_index]

    header = "🖥️ <b>Список всех серверов</b>"

    server_blocks = []
    for ip, config in servers_on_page:
        if config.get(
                'status') == 'premium' and message.from_user.id not in get_all_admins():
            continue

        installed_bots = len(await db.get_userbots_by_server_ip(ip))
        status = config.get('status', 'false')

        status_map = {
            "true": "🟢 Онлайн",
            "false": "🔴 Оффлайн",
            "test": "🧪 Тестовый",
            "noub": "🔵 Закрыт для установки",
            "premium": "💎 Премиум"
        }
        status_text = status_map.get(status, "⚪️ Неизвестно")

        premium_emoji = "💎 " if status == 'premium' else ""

        server_block = (
            f"<b>{premium_emoji}{config.get('flag', '🏳️')} {config.get('name', ip)} ({config.get('code', 'N/A')})</b>\n"
            f"  - <b>IP:</b> <code>{ip}</code>\n"
            f"  - <b>Статус:</b> {status_text}\n"
            f"  - <b>Слоты:</b> <code>{installed_bots} / {config.get('slots', 0)}</code>")
        server_blocks.append(server_block)

    content = "\n\n".join(server_blocks)
    pagination_info = f"\n\n<i>📄 Страница {page} из {total_pages}</i>" if total_pages > 1 else ""

    text = f"<blockquote expandable>{header}\n\n{content}{pagination_info}</blockquote>"

    markup = kb.get_servers_paginator_keyboard(
        page, total_pages) if total_pages > 1 else None

    try:
        if is_edit:
            await message.edit_text(text, reply_markup=markup)
        else:
            await message.reply(text, reply_markup=markup)
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Ошибка при отправке списка серверов: {e}")


@router.message(Command("servers"), IsAdmin())
async def cmd_servers(message: types.Message):
    await _send_servers_page(message, page=1, is_edit=False)


@router.callback_query(F.data.startswith("servers_page:"), IsAdmin())
async def cq_servers_page(call: types.CallbackQuery):
    await call.answer()
    try:
        page = int(call.data.split(":")[1])
        await _send_servers_page(call.message, page=page, is_edit=True)
    except (ValueError, IndexError):
        await call.answer("Ошибка данных пагинации.", show_alert=True)


@router.message(Command("update_check"), IsSuperAdmin())
async def cmd_update_check(message: types.Message, bot: Bot):
    msg = await message.reply("⏳ <b>Принудительная проверка сессий...</b>\n\nИщу пользователей с >1 сессией и отправляю актуальный отчет в лог-канал.")

    try:
        found_violations = await session_checker.check_and_log_session_violations(bot, force=True)

        if found_violations:
            await msg.edit_text(f"✅ <b>Проверка завершена.</b>\n\nОбнаружено и залогировано нарушителей: {found_violations}.")
        else:
            await msg.edit_text("✅ <b>Проверка завершена.</b>\n\nНарушителей с более чем одной сессией не найдено.")

    except Exception as e:
        logging.error(
            f"Ошибка при выполнении /update_check: {e}",
            exc_info=True)
        await msg.edit_text(f"❌ Произошла ошибка во время принудительной проверки: {e}")


@router.message(Command("admin"), IsSuperAdmin())
async def cmd_admin(message: types.Message, command: CommandObject, bot: Bot):
    args = command.args.split() if command.args else []

    if not args:
        await message.reply(
            "Формат:\n"
            "/admin &lt;add|del&gt; &lt;admin|super&gt; &lt;ID|@|reply&gt;\n"
            "/admin list &lt;admin|super&gt;"
        )
        return

    action = args[0].lower()

    if action == "list":
        if len(args) != 2:
            await message.reply("Формат: /admin list &lt;admin|super&gt;")
            return

        level = args[1].lower()
        ids_to_show = []
        header_text = ""

        if level == "admin":
            ids_to_show = get_admin_ids()
            header_text = "<b>Администраторы:</b>\n"
        elif level == "super":
            ids_to_show = config.SUPER_ADMIN_IDS
            header_text = "<b>Супер-администраторы:</b>\n"
        else:
            await message.reply("Ошибка: неверный уровень. Используйте: admin, super.")
            return

        if not ids_to_show:
            await message.reply("Список пуст.")
            return

        tasks = [bot.get_chat(user_id) for user_id in set(ids_to_show)]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        text_parts = []
        for user_id, result in zip(set(ids_to_show), results):
            if isinstance(result, Exception):
                text_parts.append(
                    f"• <code>{user_id}</code> (Не удалось получить инфо)")
            else:
                text_parts.append(
                    f"• {html.quote(result.full_name)} (<code>{user_id}</code>)")

        await message.reply(header_text + "\n".join(text_parts))
        return

    if len(args) < 2 or (len(args) < 3 and not message.reply_to_message):
        await message.reply("Формат: /admin &lt;add|del&gt; &lt;admin|super&gt; &lt;ID|@|reply&gt;")
        return

    level = args[1].lower()

    if action not in ["add", "del"] or level not in ["admin", "super"]:
        await message.reply("Ошибка: неверное действие или уровень.")
        return

    target_args_str = " ".join(args[2:]) if len(args) > 2 else ""
    target_cmd_obj = CommandObject(command="admin", args=target_args_str)
    target_user_data, error = await _get_target_user_data(message, target_cmd_obj, bot)

    if error:
        await message.reply("Ошибка: укажите пользователя.")
        return

    target_id = target_user_data['tg_user_id']

    if target_id == message.from_user.id:
        await message.reply("Вы не можете изменять свои права.")
        return

    if action == "add":
        if level == "admin":
            if target_id in config.SUPER_ADMIN_IDS:
                await message.reply("❗️ Уже является супер-админом.")
                return
            if add_admin(target_id):
                await message.reply("✅ Права админа выданы.")
            else:
                await message.reply("❗️ Уже является админом.")
        elif level == "super":
            if add_super_admin(target_id):
                await message.reply("✅ Права супер-админа выданы.")
            else:
                await message.reply("❗️ Уже является супер-админом.")

    elif action == "del":
        if level == "admin":
            if remove_admin(target_id):
                await message.reply("✅ Права админа отозваны.")
            else:
                await message.reply("❗️ Не является админом.")
        elif level == "super":
            if remove_super_admin(target_id):
                await message.reply("✅ Права супер-админа отозваны.")
            else:
                await message.reply("❗️ Не является супер-админом.")


@router.message(Command("update_ns"), IsSuperAdmin())
async def cmd_update_ns(message: types.Message, bot: Bot):
    await message.reply("⏳ Ищу юзерботов без сессии...")
    await session_checker.run_missing_session_check_and_propose_cleanup(bot, manual_trigger=True)


@router.callback_query(F.data == "cleanup_refresh", IsSuperAdmin())
async def cq_cleanup_refresh(call: types.CallbackQuery, bot: Bot):
    await call.answer("Обновляю список...")
    await session_checker.run_missing_session_check_and_propose_cleanup(bot, manual_trigger=True)


@router.callback_query(F.data.startswith("cleanup_confirm:"), IsSuperAdmin())
async def cq_cleanup_confirm(call: types.CallbackQuery, bot: Bot):
    cleanup_id = call.data.split(":")[1]
    
    candidates = session_checker.CLEANUP_CANDIDATES_CACHE.get(cleanup_id)
    
    if not candidates:
        await call.answer("Список устарел, нажмите Обновить.", show_alert=True)
        return

    try:
        await call.message.edit_text("<b>Очищаю от мусора...</b>", parse_mode="HTML")
    except TelegramBadRequest:
        pass

    deleted_count = 0
    
    for bot_data in candidates:
        ub_username = bot_data['ub_username']
        server_ip = bot_data['server_ip']
        
        res = await api_manager.delete_container(ub_username, server_ip)
        
        if res.get("success") or "not found" in str(res.get("error", "")).lower():
            await db.delete_userbot_record(ub_username)
            deleted_count += 1
        
        await asyncio.sleep(0.2)

    session_checker.CLEANUP_CANDIDATES_CACHE.pop(cleanup_id, None)

    await call.answer(f"Удалено {deleted_count} контейнеров.", show_alert=True)
    await session_checker.run_missing_session_check_and_propose_cleanup(bot, manual_trigger=True)


@router.callback_query(F.data.startswith("cleanup_cancel:"), IsSuperAdmin())
async def cq_cleanup_missing_sessions_cancel(call: types.CallbackQuery):
    cleanup_id = call.data.split(":")[1]
    session_checker.CLEANUP_CANDIDATES_CACHE.pop(cleanup_id, None)
    await call.answer("Отменено!")
    await call.message.delete()
    await call.message.answer("Очистка отменена!")
    _clear_cleanup_message_id_file()


def _clear_cleanup_message_id_file():
    if os.path.exists(CLEANUP_PROPOSAL_MESSAGE_ID_FILE):
        try:
            os.remove(CLEANUP_PROPOSAL_MESSAGE_ID_FILE)
        except OSError as e:
            logging.error(
                f"Не удалось удалить файл ID сообщения об очистке: {e}")


@router.message(Command("validses"), IsSuperAdmin())
async def cmd_validate_sessions(message: types.Message):
    msg = await message.reply("⏳ <b>Проверяю целостность сессий на всех серверах...</b>\n<i>Ищу пустые (0 байт), битые (SQLite error) или отсутствующие файлы.</i>")
    
    servers = server_config.get_servers()
    remote_servers = {ip: details for ip, details in servers.items() if ip != sm.LOCAL_IP}
    
    if not remote_servers:
        await msg.edit_text("❌ Нет подключенных удаленных серверов.")
        return

    tasks = [api_manager.validate_sessions(ip) for ip in remote_servers.keys()]
    results = await asyncio.gather(*tasks)
    
    report_lines = []
    has_issues = False
    
    for (ip, details), res in zip(remote_servers.items(), results):
        server_code = details.get('code', 'N/A')
        server_flag = details.get('flag', '🏳️')
        
        if not res.get("success"):
            report_lines.append(f"<b>{server_flag} {server_code}:</b> ❌ Ошибка API")
            continue
            
        problems = res.get("data", {}).get("report", {})
        
        if not problems:
            continue
            
        has_issues = True
        report_lines.append(f"<b>{server_flag} {server_code}:</b>")
        
        for ub_name, issue in problems.items():
            icon = "❓"
            if issue == "missing": icon = "🗑 Нет файла"
            elif issue == "empty": icon = "0️⃣ 0 байт"
            elif issue == "corrupt": icon = "💀 Битый файл"
            
            report_lines.append(f"  • <code>{ub_name}</code> — {icon}")
            
    if not has_issues:
        await msg.edit_text("✅ <b>Все проверки пройдены!</b>\nБитых, пустых или отсутствующих сессий не обнаружено.")
    else:
        text = "⚠️ <b>Обнаружены проблемные сессии:</b>\n\n" + "\n".join(report_lines)
        if len(text) > 4096:
            from aiogram.types import BufferedInputFile
            file = BufferedInputFile(text.encode("utf-8"), filename="session_integrity_report.txt")
            await msg.delete()
            await message.answer_document(file, caption="⚠️ <b>Отчет о битых сессиях</b> (слишком большой для сообщения)")
        else:
            await msg.edit_text(text)


@router.message(Command("deletedvpns"), IsSuperAdmin())
async def cmd_deletedvpns(message: types.Message, bot: Bot):
    msg = await message.reply("⏳ <b>Начинаю проверку и очистку VPN-аккаунтов...</b>\nЭто может занять некоторое время.")

    try:
        local_userbots = await db.get_all_userbots_full_info()
        valid_owners_ids = set()
        for ub in local_userbots:
            if ub.get('tg_user_id'):
                valid_owners_ids.add(int(ub['tg_user_id']))
    except Exception as e:
        await msg.edit_text(f"❌ Ошибка при чтении локальной базы данных: {e}")
        return

    vpn_response = await api_manager.get_all_vpn_users()
    if not vpn_response.get("success"):
        await msg.edit_text(f"❌ Ошибка при получении списка VPN пользователей: {vpn_response.get('error')}")
        return

    vpn_users_list = vpn_response.get("data", [])
    if not vpn_users_list:
        await msg.edit_text("⚠️ Список пользователей VPN пуст или не удалось его прочитать.")
        return

    deleted_count = 0
    errors_count = 0
    checked_count = 0
    details_log = []

    for vpn_user in vpn_users_list:
        username = vpn_user.get("username", "")
        
        if not username.startswith("ub"):
            continue
            
        checked_count += 1
        
        try:
            user_id_str = username[2:]
            if not user_id_str.isdigit():
                continue
            
            vpn_user_id = int(user_id_str)
            
            if vpn_user_id not in valid_owners_ids:
                delete_res = await api_manager.delete_vpn(username)
                if delete_res.get("success"):
                    deleted_count += 1
                    details_log.append(f"✅ Удален: <code>{username}</code>")
                else:
                    errors_count += 1
                    details_log.append(f"❌ Ошибка удаления <code>{username}</code>")
                
                await asyncio.sleep(0.1)
                
        except Exception as e:
            logging.error(f"Ошибка при обработке VPN юзера {username}: {e}")
            continue

    report_header = (
        f"🧹 <b>Очистка VPN-аккаунтов завершена</b>\n\n"
        f"🔎 Проверено 'ub' аккаунтов: {checked_count}\n"
        f"🗑 Удалено (сирот): {deleted_count}\n"
        f"⚠️ Ошибок удаления: {errors_count}\n"
    )
    
    log_text = "\n".join(details_log)
    full_text = report_header + "\n" + log_text
    
    if len(full_text) > 4000:
        file = BufferedInputFile(full_text.encode("utf-8"), filename="vpn_cleanup_report.txt")
        await msg.delete()
        await message.answer_document(file, caption=report_header)
    else:
        if not details_log:
            full_text += "\n<i>Лишних аккаунтов не найдено.</i>"
        await msg.edit_text(full_text)


async def _get_all_active_containers() -> dict:
    servers = server_config.get_servers()
    tasks = []
    server_ips = []

    for ip, details in servers.items():
        if details.get('status') == 'false':
            continue
        tasks.append(api_manager.get_container_list(ip))
        server_ips.append((ip, details))

    if not tasks:
        return {}

    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    active_containers = {}

    for (ip, details), result in zip(server_ips, results):
        if isinstance(result, Exception):
            logging.error(f"Error fetching containers from {ip}: {result}")
            continue
        
        if isinstance(result, dict) and result.get("success"):
            containers = result.get("data", {}).get("list", [])
            for cont in containers:
                name = cont.get('name')
                status = cont.get('status')
                if name:
                    active_containers[name] = {
                        'status': status,
                        'server_ip': ip,
                        'server_code': details.get('code', 'N/A'),
                        'server_flag': details.get('flag', '🏳️')
                    }
    
    return active_containers


async def _get_users_data_with_status(force_refresh=False):
    global USERS_CACHE
    current_time = time.time()

    if not force_refresh and USERS_CACHE.get("data") and (current_time - USERS_CACHE.get("timestamp", 0) < USERS_CACHE_TTL):
        return USERS_CACHE["data"]

    all_users = await db.get_all_registered_users()
    all_bots = await db.get_all_userbots_full_info()
    
    containers_status = await _get_all_active_containers()

    users_map = {u['tg_user_id']: u for u in all_users}
    for u in all_users:
        u['bots'] = []
        u['sort_priority'] = 3

    for bot in all_bots:
        owner_id = bot['tg_user_id']
        if owner_id in users_map:
            ub_name = bot['ub_username']
            
            real_info = containers_status.get(ub_name)
            if real_info:
                bot['real_status'] = real_info['status']
                bot['server_code'] = real_info['server_code']
                bot['server_flag'] = real_info['server_flag']
            else:
                bot['real_status'] = 'unknown'
                srv = server_config.get_servers().get(bot['server_ip'], {})
                bot['server_code'] = srv.get('code', 'N/A')
                bot['server_flag'] = srv.get('flag', '🏳️')

            users_map[owner_id]['bots'].append(bot)

            if bot['real_status'] == 'running':
                users_map[owner_id]['sort_priority'] = 1
            elif users_map[owner_id]['sort_priority'] != 1:
                users_map[owner_id]['sort_priority'] = 2

    sorted_users = sorted(
        all_users, 
        key=lambda x: (x['sort_priority'], -x['tg_user_id'])
    )
    
    USERS_CACHE = {
        "data": sorted_users,
        "timestamp": current_time
    }
    
    return sorted_users


async def _generate_users_page_text(users_on_page: list) -> str:
    if not users_on_page:
        return "В этой категории нет пользователей."

    lines = []
    for user in users_on_page:
        user_id = user['tg_user_id']
        username = f"@{user['username']}" if user.get('username') else "Без юзернейма"
        full_name = html.quote(user.get('full_name', 'Name'))
        
        header = f"👤 <b>{full_name}</b> ({username}) <code>{user_id}</code>"
        
        bots_lines = []
        if user['bots']:
            for bot in user['bots']:
                status_icon = "🟢" if bot.get('real_status') == 'running' else "🔴"
                ub_type = bot.get('ub_type', 'unknown').capitalize()
                server_info = f"{bot.get('server_flag', '')} {bot.get('server_code', '')}"
                
                bot_line = (
                    f"   └ {status_icon} <b>{bot['ub_username']}</b> ({ub_type}) "
                    f"| {server_info}"
                )
                bots_lines.append(bot_line)
        else:
            bots_lines.append("   └ ⚪️ <i>Нет юзерботов</i>")

        if user.get('note'):
            bots_lines.append(f"   └ 📝 <i>{html.quote(user['note'])}</i>")

        lines.append(header + "\n" + "\n".join(bots_lines))

    return "\n\n".join(lines)


async def _get_paginated_users_text_and_markup(bot: Bot, view_mode: str, page: int, force_refresh=False):
    page_size = 7
    
    if view_mode == "visible":
        user_list = await _get_users_data_with_status(force_refresh=force_refresh)
        header = "<b>👥 Список пользователей (Docker Monitoring)</b>\n\n"
    else:
        user_list = await db.get_all_unregistered_users()
        for u in user_list:
            u['bots'] = []
        header = "<b>👻 Список скрытых пользователей (не приняли соглашение)</b>\n\n"

    total_items = len(user_list)
    total_pages = max(1, (total_items + page_size - 1) // page_size)
    page = max(1, min(page, total_pages))

    start_index = (page - 1) * page_size
    end_index = start_index + page_size
    users_on_page = user_list[start_index:end_index]

    text_body = await _generate_users_page_text(users_on_page)
    
    stats_line = f"\n\n📊 <b>Всего:</b> {total_items} | <b>Стр:</b> {page}/{total_pages}"
    full_text = header + text_body + stats_line

    markup = kb.get_user_list_paginator(page, total_pages, view_mode)

    return full_text, markup


@router.message(Command("users"), IsAdmin())
async def cmd_users_list(message: types.Message, bot: Bot):
    msg = await message.reply("⏳ <b>Обновляю данные с кластера...</b>")
    try:
        text, markup = await _get_paginated_users_text_and_markup(bot, view_mode="visible", page=1, force_refresh=True)
        await msg.edit_text(text=text, reply_markup=markup)
    except Exception as e:
        logging.error(f"Error in /users: {e}", exc_info=True)
        await msg.edit_text(f"❌ Произошла ошибка при сборе данных: {e}")


@router.callback_query(F.data.startswith("user_page:"), IsAdmin())
async def user_list_paginator_handler(call: types.CallbackQuery, bot: Bot):
    try:
        await call.answer()
    except:
        pass
        
    _, view_mode, page_str = call.data.split(':')
    page = int(page_str)
    
    text, markup = await _get_paginated_users_text_and_markup(bot, view_mode=view_mode, page=page, force_refresh=False)
    
    try:
        await call.message.edit_text(text=text, reply_markup=markup)
    except TelegramBadRequest as e:
        if "message is not modified" not in str(e).lower():
            logging.error(f"Error pagination: {e}")


@router.callback_query(F.data.startswith("user_view_toggle:"), IsAdmin())
async def toggle_user_visibility_handler(call: types.CallbackQuery, bot: Bot):
    try:
        await call.answer("Переключение режима...")
    except:
        pass
        
    new_view_mode = call.data.split(':')[1]
    text, markup = await _get_paginated_users_text_and_markup(bot, view_mode=new_view_mode, page=1, force_refresh=False)
    await call.message.edit_text(text=text, reply_markup=markup)